<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Exceptions\HttpException;
use App\Repositories\AlertaRepository;
use App\Repositories\CronogramaRepository;
use App\Repositories\MatrizRepository;
use App\Repositories\PlanAnualRepository;
use App\Repositories\SesionRepository;
use PDOException;

class CronogramaService
{
    private CronogramaRepository $repo;
    private DashboardService $periodos;
    private SesionRepository $sesiones;
    private SesionService $sesionService;
    private MatrizRepository $matriz;
    private PersonalService $personal;
    private AlertaRepository $alertas;
    private PlanAnualRepository $planes;
    private AuditoriaService $auditoria;

    public function __construct()
    {
        $this->repo = new CronogramaRepository();
        $this->periodos = new DashboardService();
        $this->sesiones = new SesionRepository();
        $this->sesionService = new SesionService();
        $this->matriz = new MatrizRepository();
        $this->personal = new PersonalService();
        $this->alertas = new AlertaRepository();
        $this->planes = new PlanAnualRepository();
        $this->auditoria = new AuditoriaService();
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array<string,mixed>
     */
    public function tablero(array $filtros): array
    {
        $periodo = $this->periodos->periodo($filtros);
        $procesoId = isset($filtros['proceso_id']) && $filtros['proceso_id'] !== null && $filtros['proceso_id'] !== ''
            ? (int)$filtros['proceso_id']
            : null;
        $proyecto = $this->proyectoFiltro($procesoId, $filtros['proyecto'] ?? null);
        $buscar = nullable_trimmed_string($filtros['buscar'] ?? null);

        $filas = $this->repo->programadas($periodo, $procesoId, $proyecto, $buscar);
        $procesos = $this->alertas->procesosActivos();
        $detalleIds = [];
        foreach ($filas as $fila) {
            $id = isset($fila['plan_detalle_id']) ? (int)$fila['plan_detalle_id'] : 0;
            if ($id > 0) {
                $detalleIds[] = $id;
            }
        }
        $sesionesPorDetalle = $this->sesionesPorDetalle($detalleIds);
        $sesionesPorCapMes = $this->sesionesPorCapacitacionMes(
            array_map(static fn (array $f): int => (int)$f['capacitacion_id'], $filas),
            (int)$periodo['anio']
        );
        $alcancesPor = $this->planes->alcancesPorDetalles($detalleIds);
        $porMes = [];
        $items = [];
        foreach ($filas as $fila) {
            $detalleId = isset($fila['plan_detalle_id']) ? (int)$fila['plan_detalle_id'] : 0;
            $capId = (int)$fila['capacitacion_id'];
            $mes = (int)$fila['mes_programado'];
            if ($detalleId < 1) {
                $fila['plan_detalle_id'] = null;
                $sesionesMapa = [0 => $sesionesPorCapMes[$capId . ':' . $mes] ?? []];
                $alcances = [];
            } else {
                $sesionesMapa = $sesionesPorDetalle;
                $alcances = $alcancesPor[$detalleId] ?? [];
            }
            $item = $this->item($fila, $sesionesMapa, $alcances);
            $items[] = $item;
            $porMes[$mes][] = $item;
        }

        $meses = [];
        foreach ($periodo['meses'] as $mes) {
            $itemsMes = $porMes[$mes] ?? [];
            $meses[] = [
                'mes' => $mes,
                'nombre' => $this->nombreMes($mes),
                'total' => count($itemsMes),
                'items' => $itemsMes,
            ];
        }

        $procesoNombre = null;
        if ($procesoId !== null) {
            foreach ($procesos as $proceso) {
                if ($proceso['proceso_id'] === $procesoId) {
                    $procesoNombre = $proceso['nombre'];
                    break;
                }
            }
        }

        return [
            'periodo' => [
                'tipo' => $periodo['tipo'],
                'anio' => $periodo['anio'],
                'mes' => $periodo['mes'],
                'trimestre' => $periodo['trimestre'],
                'semestre' => $periodo['semestre'] ?? null,
                'etiqueta' => $periodo['etiqueta'],
            ],
            'proceso_id' => $procesoId,
            'proceso_nombre' => $procesoNombre,
            'proyecto' => $proyecto,
            'total' => count($items),
            'estado_plan' => 'APROBADO',
            'procesos' => $procesos,
            'proyectos' => $this->alertas->proyectos(),
            'items' => $items,
            'meses' => $meses,
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function ver(int $detalleId): array
    {
        $fila = $this->exigirAprobado($detalleId);
        $anio = (int)$fila['anio'];
        $mes = (int)($fila['mes_programado'] ?? 0);
        if ($mes < 1 && !empty($fila['fecha_programada'])) {
            $mes = (int)substr((string)$fila['fecha_programada'], 5, 2);
        }
        if ($mes >= 1 && $mes <= 12) {
            $periodo = $this->repo->periodoGrupo((int)$fila['capacitacion_id'], $anio, $mes);
            $fila['fecha_desde'] = $periodo['fecha_desde'];
            $fila['fecha_hasta'] = $periodo['fecha_hasta'];
            if ($periodo['cantidad'] > 0) {
                $fila['cantidad_programada'] = $periodo['cantidad'];
            }
            $grupo = $this->repo->buscarGrupo((int)$fila['capacitacion_id'], $anio, $mes);
            if ($grupo !== null) {
                $fila['ejecutadas_fuera_de_tiempo'] = $grupo['ejecutadas_fuera_de_tiempo'] ?? 0;
                $fila['pendientes_fuera_plazo'] = $grupo['pendientes_fuera_plazo'] ?? 0;
            }
        }
        $sesiones = $this->sesionesPorDetalle([$detalleId]);

        return $this->item($fila, $sesiones);
    }

    /**
     * @return array{items:list<array<string,mixed>>,total:int,cantidad_programada:int,fecha_desde:?string,fecha_hasta:?string}
     */
    public function trabajadores(int $detalleId): array
    {
        $fila = $this->exigirAprobado($detalleId);
        $anio = (int)$fila['anio'];
        $mes = (int)$fila['mes_programado'];

        return $this->trabajadoresDeGrupo((int)$fila['capacitacion_id'], $anio, $mes, (int)$fila['cantidad_programada']);
    }

    /**
     * @return array{items:list<array<string,mixed>>,total:int,cantidad_programada:int,fecha_desde:?string,fecha_hasta:?string}
     */
    public function trabajadoresGrupo(int $capacitacionId, int $anio, int $mes): array
    {
        $fila = $this->exigirGrupo($capacitacionId, $anio, $mes);

        return $this->trabajadoresDeGrupo($capacitacionId, $anio, $mes, (int)$fila['cantidad_programada']);
    }

    /**
     * @return array<string,mixed>
     */
    public function verGrupo(int $capacitacionId, int $anio, int $mes): array
    {
        $fila = $this->exigirGrupo($capacitacionId, $anio, $mes);
        $sesiones = $this->sesionesPorCapacitacionMes([$capacitacionId], $anio);

        return $this->item($fila, [0 => $sesiones[$capacitacionId . ':' . $mes] ?? []]);
    }

    /**
     * @return array<string,mixed>
     */
    public function iniciarGrupo(int $capacitacionId, int $anio, int $mes, int $usuarioId): array
    {
        $fila = $this->exigirGrupo($capacitacionId, $anio, $mes);
        if (strtoupper((string)($fila['estado_programacion'] ?? 'PROGRAMADA')) === 'CANCELADA') {
            throw new HttpException('No es posible iniciar una programación cancelada.', 409);
        }

        $detalleId = isset($fila['plan_detalle_id']) ? (int)$fila['plan_detalle_id'] : 0;
        $clave = $capacitacionId . ':' . $mes;
        $existentes = $detalleId > 0
            ? ($this->sesionesPorDetalle([$detalleId])[$detalleId] ?? [])
            : ($this->sesionesPorCapacitacionMes([$capacitacionId], $anio)[$clave] ?? []);

        $huboEjecutada = false;
        foreach ($existentes as $sesion) {
            $estado = strtoupper((string)($sesion['estado'] ?? ''));
            if ($estado === 'PROGRAMADA') {
                $sesionId = (int)($sesion['sesion_id'] ?? 0);
                if ($sesionId > 0 && (int)($sesion['convocados'] ?? 0) === 0) {
                    $this->sesionService->sincronizarConvocados($sesionId, $usuarioId, true);
                }

                return $detalleId > 0 ? $this->ver($detalleId) : $this->verGrupo($capacitacionId, $anio, $mes);
            }
            if ($estado === 'EJECUTADA') {
                $huboEjecutada = true;
            }
        }

        $fechaHasta = isset($fila['fecha_hasta']) && $fila['fecha_hasta'] !== null && $fila['fecha_hasta'] !== ''
            ? substr((string)$fila['fecha_hasta'], 0, 10)
            : (isset($fila['fecha_programada']) && $fila['fecha_programada'] !== null && $fila['fecha_programada'] !== ''
                ? substr((string)$fila['fecha_programada'], 0, 10)
                : sprintf('%04d-%02d-01', $anio, $mes));
        $hoy = date('Y-m-d');
        if ($huboEjecutada && $fechaHasta < $hoy) {
            $fechaHasta = $hoy;
        }

        $lista = $this->trabajadoresDeGrupo($capacitacionId, $anio, $mes, (int)$fila['cantidad_programada']);
        $items = $lista['items'];
        if ($huboEjecutada) {
            $items = array_values(array_filter(
                $items,
                static fn (array $t): bool => self::asignacionPendienteDeCumplir($t)
            ));
            if ($items === []) {
                throw new HttpException(
                    'No hay trabajadores pendientes para una nueva sesión. Si ya asistieron y solo falta aprobar o corregir la nota, use «Completar».',
                    409
                );
            }
        }

        $asignacionIds = array_map(
            static fn (array $t): int => (int)$t['asignacion_id'],
            $items
        );
        $cupo = max(count($asignacionIds), $huboEjecutada ? 1 : (int)$fila['cantidad_programada'], 1);
        $catalogo = $this->datosInicioSesion($fila);

        $this->sesionService->crear([
            'plan_detalle_id' => $detalleId > 0 ? $detalleId : null,
            'capacitacion_id' => $capacitacionId,
            'fecha' => $fechaHasta,
            'hora' => '08:00',
            'modalidad_id' => $catalogo['modalidad_id'],
            'ubicacion_id' => $catalogo['ubicacion_id'],
            'enlace_virtual' => $catalogo['enlace_virtual'],
            'proveedor_id' => $catalogo['proveedor_id'],
            'cupo_maximo' => $cupo,
            'asignacion_ids' => $asignacionIds,
        ], $usuarioId);

        return $detalleId > 0 ? $this->ver($detalleId) : $this->verGrupo($capacitacionId, $anio, $mes);
    }

    /**
     * Elegible para nueva sesión (reintento): reutiliza la misma asignación.
     * Incluye ausentes y quienes asistieron pero siguen PENDIENTE (reprobados / sin APROBADO).
     * No incluye COMPLETADA / VENCIDA / PROXIMA_A_VENCER.
     *
     * @param array<string,mixed> $trabajador
     */
    private static function asignacionPendienteDeCumplir(array $trabajador): bool
    {
        $estado = strtoupper((string)($trabajador['estado_asignacion'] ?? ''));

        return $estado === '' || str_starts_with($estado, 'PENDIENTE');
    }

    /**
     * Agrega persona faltante: crea asignación MANUAL del periodo del grupo y opcionalmente convoca.
     *
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array{asignacion:array<string,mixed>,item:array<string,mixed>}
     */
    public function agregarPersonaGrupo(
        int $capacitacionId,
        int $anio,
        int $mes,
        int $personaId,
        int $usuarioId,
        ?int $sesionId = null,
        ?array $actor = null
    ): array {
        $fila = $this->exigirGrupo($capacitacionId, $anio, $mes);
        $periodo = $this->repo->periodoGrupo($capacitacionId, $anio, $mes);
        $fechaDesde = $periodo['fecha_desde'] ?? sprintf('%04d-%02d-01', $anio, $mes);
        $fechaHasta = $periodo['fecha_hasta'] ?? sprintf(
            '%04d-%02d-%02d',
            $anio,
            $mes,
            (int)(new \DateTimeImmutable(sprintf('%04d-%02d-01', $anio, $mes)))->format('t')
        );

        $asignaciones = new AsignacionService();
        $asignacion = $asignaciones->crear([
            'persona_id_ext' => $personaId,
            'capacitacion_id' => $capacitacionId,
            'fecha_asignacion' => $fechaDesde,
            'fecha_limite_cumplimiento' => $fechaHasta,
        ], $usuarioId, $actor);

        if ($sesionId !== null && $sesionId > 0) {
            $this->sesionService->convocar($sesionId, [
                'asignacion_ids' => [(int)$asignacion['asignacion_id']],
            ], $usuarioId);
        }

        $detalleId = isset($fila['plan_detalle_id']) ? (int)$fila['plan_detalle_id'] : 0;

        return [
            'asignacion' => $asignacion,
            'item' => $detalleId > 0 ? $this->ver($detalleId) : $this->verGrupo($capacitacionId, $anio, $mes),
        ];
    }

    /**
     * @return array{items:list<array<string,mixed>>,total:int,cantidad_programada:int,fecha_desde:?string,fecha_hasta:?string}
     */
    private function trabajadoresDeGrupo(int $capacitacionId, int $anio, int $mes, int $cantidadProgramada): array
    {
        $filas = $this->repo->trabajadoresPorPlazo($capacitacionId, $anio, $mes);
        $periodo = $this->repo->periodoGrupo($capacitacionId, $anio, $mes);
        $items = [];
        foreach ($filas as $t) {
            $fechaReal = $t['fecha_realizacion'] ?? null;
            $fechaHasta = $t['fecha_limite_cumplimiento'] ?? null;
            $fuera = (int)($t['ejecutada_fuera_de_tiempo'] ?? 0) === 1;
            $items[] = [
                'asignacion_id' => (int)$t['asignacion_id'],
                'persona_id_ext' => (int)$t['persona_id_ext'],
                'numero_documento' => (string)($t['numero_documento'] ?? ''),
                'persona_nombre' => (string)($t['persona_nombre'] ?? ''),
                'nombre_cargo' => $t['nombre_cargo'] !== null && $t['nombre_cargo'] !== ''
                    ? (string)$t['nombre_cargo']
                    : null,
                'proyecto' => $t['proyecto'] !== null && $t['proyecto'] !== ''
                    ? (string)$t['proyecto']
                    : null,
                'fecha_asignacion' => $t['fecha_asignacion'] !== null
                    ? substr((string)$t['fecha_asignacion'], 0, 10)
                    : null,
                'fecha_limite_cumplimiento' => $fechaHasta !== null
                    ? substr((string)$fechaHasta, 0, 10)
                    : null,
                'fecha_realizacion' => $fechaReal !== null
                    ? substr((string)$fechaReal, 0, 10)
                    : null,
                'estado_asignacion' => (string)($t['estado_calculado'] ?? ''),
                'ejecutada_fuera_de_tiempo' => $fuera,
                'dentro_de_tiempo' => $fechaReal !== null && !$fuera,
            ];
        }

        return [
            'items' => $items,
            'total' => count($items),
            'cantidad_programada' => $cantidadProgramada > 0 ? $cantidadProgramada : count($items),
            'fecha_desde' => $periodo['fecha_desde'],
            'fecha_hasta' => $periodo['fecha_hasta'],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function exigirGrupo(int $capacitacionId, int $anio, int $mes): array
    {
        $fila = $this->repo->buscarGrupo($capacitacionId, $anio, $mes);
        if ($fila === null) {
            throw new HttpException('No hay asignaciones para esa capacitación en el periodo indicado.', 404);
        }
        $fila['anio'] = $anio;

        return $fila;
    }

    /**
     * @param array<string,mixed> $datos
     * @return array<string,mixed>
     */
    /**
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function reprogramar(int $detalleId, array $datos, ?array $actor = null): array
    {
        $fila = $this->exigirAprobado($detalleId);
        if (strtoupper((string)($fila['estado_programacion'] ?? 'PROGRAMADA')) === 'CANCELADA') {
            throw new HttpException('No es posible reprogramar una programación cancelada.', 409);
        }

        $anio = (int)$fila['anio'];
        $fecha = $this->fechaEnAnio((string)($datos['fecha_programada'] ?? ''), $anio);
        $mes = (int)substr($fecha, 5, 2);
        $fechaAnterior = substr((string)($fila['fecha_programada'] ?? ''), 0, 10);

        $duplicado = $this->planes->buscarDetallePorCapacitacion(
            (int)$fila['plan_anual_id'],
            (int)$fila['capacitacion_id'],
            $detalleId
        );
        if ($duplicado !== null && (int)$duplicado['plan_detalle_id'] !== $detalleId) {
            throw new HttpException('Esta capacitación ya está contemplada en el plan anual.', 409);
        }

        try {
            $this->planes->actualizarDetalle($detalleId, [
                'fecha_programada' => $fecha,
                'mes_programado' => $mes,
            ]);
            $this->sesiones->alinearFechaProgramada($detalleId, $fecha);
        } catch (PDOException $e) {
            throw new HttpException('No fue posible guardar la programación.', 500);
        }

        $despues = $this->ver($detalleId);
        if ($actor !== null && $fechaAnterior !== $fecha) {
            $cambios = [[
                'campo' => 'fecha_programada',
                'etiqueta' => 'Fecha programada',
                'anterior' => $fechaAnterior !== '' ? $fechaAnterior : null,
                'nuevo' => $fecha,
            ]];
            $this->auditoria->deActor(
                $actor,
                'reprogramar',
                'plan_anual_detalle',
                $detalleId,
                $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO),
                ['fecha_programada' => $fechaAnterior !== '' ? $fechaAnterior : null]
            );
        }

        return $despues;
    }

    /**
     * @return array<string,mixed>
     */
    public function cancelar(int $detalleId): array
    {
        $fila = $this->exigirAprobado($detalleId);
        if (strtoupper((string)($fila['estado_programacion'] ?? 'PROGRAMADA')) === 'CANCELADA') {
            throw new HttpException('La programación ya está cancelada.', 409);
        }

        try {
            $this->planes->actualizarDetalle($detalleId, [
                'estado_programacion' => 'CANCELADA',
            ]);
        } catch (PDOException $e) {
            throw new HttpException('No fue posible guardar la programación.', 500);
        }

        return $this->ver($detalleId);
    }

    /**
     * @return array<string,mixed>
     */
    public function iniciar(int $detalleId, int $usuarioId): array
    {
        $fila = $this->exigirAprobado($detalleId);
        $anio = (int)$fila['anio'];
        $mes = (int)($fila['mes_programado'] ?? 0);
        if ($mes < 1 && !empty($fila['fecha_programada'])) {
            $mes = (int)substr((string)$fila['fecha_programada'], 5, 2);
        }
        if ($mes < 1 || $mes > 12) {
            throw new HttpException(
                'No hay fecha operativa para iniciar. Defina el plazo en Asignaciones.',
                422
            );
        }

        return $this->iniciarGrupo((int)$fila['capacitacion_id'], $anio, $mes, $usuarioId);
    }

    /**
     * @param array<string,mixed> $fila
     * @return array{modalidad_id:int,proveedor_id:int,ubicacion_id:?int,enlace_virtual:?string}
     */
    private function datosInicioSesion(array $fila): array
    {
        $modalidades = $this->sesiones->catalogoListar('modalidades', 'modalidad_id');
        $modalidadId = isset($fila['modalidad_default_id']) ? (int)$fila['modalidad_default_id'] : 0;
        $nombreModalidad = is_string($fila['metodologia'] ?? null) ? (string)$fila['metodologia'] : '';
        if ($modalidadId < 1) {
            if ($modalidades === []) {
                throw new HttpException('No hay modalidades activas en el catálogo.', 422);
            }
            $modalidadId = (int)$modalidades[0]['modalidad_id'];
            $nombreModalidad = (string)($modalidades[0]['nombre'] ?? '');
        } elseif ($nombreModalidad === '') {
            foreach ($modalidades as $modalidad) {
                if ((int)$modalidad['modalidad_id'] === $modalidadId) {
                    $nombreModalidad = (string)($modalidad['nombre'] ?? '');
                    break;
                }
            }
        }

        $proveedores = $this->sesiones->catalogoListar('proveedores_capacitadores', 'proveedor_id');
        $proveedorId = isset($fila['proveedor_default_id']) ? (int)$fila['proveedor_default_id'] : 0;
        if ($proveedorId < 1) {
            if ($proveedores === []) {
                throw new HttpException('No hay proveedores o capacitadores activos en el catálogo.', 422);
            }
            $proveedorId = (int)$proveedores[0]['proveedor_id'];
        }

        $clave = mb_strtoupper($nombreModalidad, 'UTF-8');
        $esVirtual = str_contains($clave, 'VIRTUAL');
        $esPresencial = str_contains($clave, 'PRESENCIAL');
        $esMixta = str_contains($clave, 'MIXTA');
        $ubicacionId = null;
        $enlace = null;
        if ($esPresencial || $esMixta) {
            $ubicaciones = $this->sesiones->catalogoListar('ubicaciones', 'ubicacion_id');
            if ($ubicaciones === []) {
                throw new HttpException('No hay ubicaciones activas en el catálogo.', 422);
            }
            $ubicacionId = (int)$ubicaciones[0]['ubicacion_id'];
        }
        if ($esVirtual || $esMixta) {
            throw new HttpException(
                'Para iniciar una capacitación virtual o mixta debe crear la sesión con el enlace correspondiente.',
                422
            );
        }

        return [
            'modalidad_id' => $modalidadId,
            'proveedor_id' => $proveedorId,
            'ubicacion_id' => $ubicacionId,
            'enlace_virtual' => $enlace,
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function exigirAprobado(int $detalleId): array
    {
        $fila = $this->repo->buscarProgramacion($detalleId);
        if ($fila === null) {
            throw new HttpException('La programación no existe.', 404);
        }
        if (strtoupper((string)($fila['plan_estado'] ?? '')) !== 'APROBADO') {
            throw new HttpException('El plan no se encuentra aprobado.', 409);
        }

        return $fila;
    }

    private function proyectoFiltro(?int $procesoId, mixed $proyecto): ?string
    {
        if ($procesoId === null || $procesoId < 1) {
            return null;
        }
        if (!$this->alertas->procesoEsGestionProyectos($procesoId)) {
            return null;
        }

        $normalizado = nullable_trimmed_string($proyecto);
        if ($normalizado === null || $normalizado === '') {
            return null;
        }

        $canonico = $this->alertas->resolverProyecto($normalizado, false);
        if ($canonico === null) {
            throw new HttpException('El proyecto no es válido.', 422);
        }

        return $canonico;
    }

    private function fechaEnAnio(string $fecha, int $anio): string
    {
        $fecha = trim($fecha);
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d', $fecha);
        $errores = \DateTimeImmutable::getLastErrors();
        $conError = is_array($errores)
            && (($errores['warning_count'] ?? 0) > 0 || ($errores['error_count'] ?? 0) > 0);
        if ($dt === false || $conError) {
            throw new HttpException('La fecha de programación no es válida.', 422);
        }
        if ((int)$dt->format('Y') !== $anio) {
            throw new HttpException('La fecha debe pertenecer al año del plan.', 422);
        }

        return $dt->format('Y-m-d');
    }

    /**
     * @param array<string,mixed> $fila
     * @param array<int, list<array<string,mixed>>> $sesionesPorDetalle
     * @param list<array<string,mixed>>|null $alcances
     * @return array<string,mixed>
     */
    private function item(array $fila, array $sesionesPorDetalle, ?array $alcances = null): array
    {
        $mes = (int)$fila['mes_programado'];
        $horas = $fila['duracion_estimada_horas'];
        $metodologia = $fila['metodologia'] ?? null;
        $detalleId = isset($fila['plan_detalle_id']) && $fila['plan_detalle_id'] !== null && $fila['plan_detalle_id'] !== ''
            ? (int)$fila['plan_detalle_id']
            : 0;
        $sesiones = $sesionesPorDetalle[$detalleId] ?? ($sesionesPorDetalle[0] ?? []);
        $procesoId = $fila['proceso_id'] !== null ? (int)$fila['proceso_id'] : null;
        $proyecto = $fila['proyecto'] !== null && $fila['proyecto'] !== '' ? (string)$fila['proyecto'] : null;
        $alcances = $alcances ?? ($detalleId > 0 ? $this->planes->alcancesDeDetalle($detalleId) : []);
        $cargos = $this->cargosDeProgramacion($fila, $alcances);
        $nombresProceso = [];
        $procesoIds = [];
        foreach ($alcances as $alcance) {
            $pid = (int)($alcance['proceso_id'] ?? 0);
            if ($pid > 0) {
                $procesoIds[$pid] = $pid;
            }
            $nombre = (string)($alcance['proceso_nombre'] ?? '');
            if ($nombre !== '') {
                $nombresProceso[$nombre] = $nombre;
            }
        }
        if ($procesoIds === [] && $procesoId !== null && $procesoId > 0) {
            $procesoIds[$procesoId] = $procesoId;
        }
        $procesoNombre = $nombresProceso !== []
            ? implode(', ', array_values($nombresProceso))
            : ($fila['proceso_nombre'] !== null && $fila['proceso_nombre'] !== ''
                ? (string)$fila['proceso_nombre']
                : null);

        return [
            'plan_detalle_id' => $detalleId > 0 ? $detalleId : null,
            'plan_anual_id' => isset($fila['plan_anual_id']) && $fila['plan_anual_id'] !== null
                ? (int)$fila['plan_anual_id']
                : null,
            'grupo_key' => (int)$fila['capacitacion_id'] . '-' . (int)$fila['anio'] . '-' . $mes,
            'capacitacion_id' => (int)$fila['capacitacion_id'],
            'codigo' => (string)$fila['codigo'],
            'tema' => (string)$fila['nombre'],
            'objetivo' => (string)$fila['objetivo'],
            'horas' => $horas !== null && $horas !== '' ? round((float)$horas, 2) : null,
            'metodologia' => is_string($metodologia) && $metodologia !== '' ? $metodologia : null,
            'mes' => $mes,
            'mes_nombre' => $this->nombreMes($mes),
            'fecha_desde' => isset($fila['fecha_desde']) && $fila['fecha_desde'] !== null && $fila['fecha_desde'] !== ''
                ? substr((string)$fila['fecha_desde'], 0, 10)
                : null,
            'fecha_hasta' => isset($fila['fecha_hasta']) && $fila['fecha_hasta'] !== null && $fila['fecha_hasta'] !== ''
                ? substr((string)$fila['fecha_hasta'], 0, 10)
                : ($fila['fecha_programada'] !== null
                    ? substr((string)$fila['fecha_programada'], 0, 10)
                    : null),
            'fecha_programada' => $fila['fecha_programada'] !== null
                ? substr((string)$fila['fecha_programada'], 0, 10)
                : null,
            'cantidad_programada' => (int)$fila['cantidad_programada'],
            'ejecutadas_fuera_de_tiempo' => (int)($fila['ejecutadas_fuera_de_tiempo'] ?? 0),
            'pendientes_fuera_plazo' => (int)($fila['pendientes_fuera_plazo'] ?? 0),
            'pendientes_sin_cumplimiento' => (int)($fila['pendientes_sin_cumplimiento'] ?? 0),
            'pendientes_incompletos' => (int)($fila['pendientes_incompletos'] ?? 0),
            'anio' => (int)$fila['anio'],
            'proceso_id' => $procesoId,
            'proceso_ids' => array_values($procesoIds),
            'proceso_nombre' => $procesoNombre,
            'ambito' => $fila['ambito'] !== null && $fila['ambito'] !== '' ? (string)$fila['ambito'] : null,
            'proyecto' => $proyecto,
            'estado_programacion' => strtoupper((string)($fila['estado_programacion'] ?? 'PROGRAMADA')),
            'estado_operativo' => $this->estadoOperativo(
                (string)($fila['estado_programacion'] ?? 'PROGRAMADA'),
                $sesiones
            ),
            'requiere_evaluacion' => (int)($fila['evaluacion'] ?? 0) === 1,
            'requiere_certificado' => (int)($fila['certificado'] ?? 0) === 1,
            'vigencia_id' => $fila['vigencia_id'] !== null ? (int)$fila['vigencia_id'] : null,
            'vigencia_nombre' => humanizar_nombre_unidad(
                $fila['vigencia_nombre'] !== null && $fila['vigencia_nombre'] !== ''
                    ? (string)$fila['vigencia_nombre']
                    : null
            ),
            'vigencia_cantidad' => $fila['vigencia_cantidad'] !== null ? (int)$fila['vigencia_cantidad'] : null,
            'vigencia_unidad' => $fila['vigencia_unidad'] !== null && $fila['vigencia_unidad'] !== ''
                ? (string)$fila['vigencia_unidad']
                : null,
            'cargos_aplicables' => $cargos,
            'sesiones' => $sesiones,
        ];
    }

    /**
     * @param list<array<string,mixed>> $sesiones
     */
    private function estadoOperativo(string $estadoProgramacion, array $sesiones): string
    {
        if (strtoupper($estadoProgramacion) === 'CANCELADA') {
            return 'CANCELADA';
        }
        if ($sesiones === []) {
            return 'PROGRAMADA';
        }

        $hayProgramada = false;
        foreach ($sesiones as $sesion) {
            if (strtoupper((string)($sesion['estado'] ?? '')) === 'PROGRAMADA') {
                $hayProgramada = true;
                break;
            }
        }

        if ($hayProgramada) {
            return 'EN_EJECUCION';
        }

        return 'FINALIZADA';
    }

    /**
     * @param array<string,mixed> $fila
     * @param list<array<string,mixed>>|null $alcances
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    private function cargosDeProgramacion(array $fila, ?array $alcances = null): array
    {
        $detalleId = (int)($fila['plan_detalle_id'] ?? 0);
        $filasAlcance = $alcances ?? ($detalleId > 0 ? $this->planes->alcancesDeDetalle($detalleId) : []);
        $ids = [];
        foreach ($filasAlcance as $alcance) {
            $id = (int)($alcance['cargo_id_ext'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        if ($ids !== []) {
            return $this->nombresCargos(array_values($ids));
        }
        $procesoId = $fila['proceso_id'] !== null ? (int)$fila['proceso_id'] : 0;
        $proyecto = $fila['proyecto'] !== null && $fila['proyecto'] !== '' ? (string)$fila['proyecto'] : null;
        if ($procesoId < 1) {
            return [];
        }

        return $this->cargosAplicables((int)$fila['capacitacion_id'], $procesoId, $proyecto);
    }

    /**
     * @param list<int> $ids
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    private function nombresCargos(array $ids): array
    {
        $nombres = $this->personal->nombresCargosPorIds($ids);
        $salida = [];
        foreach ($ids as $id) {
            $salida[] = [
                'cargo_id' => $id,
                'nombre_cargo' => $nombres[$id] ?? ('Cargo ' . $id),
            ];
        }
        usort(
            $salida,
            static fn (array $a, array $b): int => strcasecmp((string)$a['nombre_cargo'], (string)$b['nombre_cargo'])
        );

        return $salida;
    }

    /**
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    private function cargosAplicables(int $capacitacionId, int $procesoId, ?string $proyecto): array
    {
        $filas = $this->matriz->cargosActivosDeCapacitacion($capacitacionId, $procesoId, $proyecto);
        $ids = [];
        foreach ($filas as $fila) {
            $id = (int)($fila['cargo_id_ext'] ?? 0);
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        $nombres = $this->personal->nombresCargosPorIds(array_values($ids));
        $salida = [];
        foreach ($ids as $id) {
            $salida[] = [
                'cargo_id' => $id,
                'nombre_cargo' => $nombres[$id] ?? ('Cargo ' . $id),
            ];
        }
        usort(
            $salida,
            static fn (array $a, array $b): int => strcasecmp((string)$a['nombre_cargo'], (string)$b['nombre_cargo'])
        );

        return $salida;
    }

    /**
     * @param list<int> $detalleIds
     * @return array<int, list<array<string,mixed>>>
     */
    private function sesionesPorDetalle(array $detalleIds): array
    {
        $mapa = [];
        foreach ($this->sesionService->resumir($this->sesiones->listarPorDetalles($detalleIds)) as $sesion) {
            $detalleId = (int)($sesion['plan_detalle_id'] ?? 0);
            if ($detalleId < 1) {
                continue;
            }
            $mapa[$detalleId][] = $sesion;
        }

        return $mapa;
    }

    /**
     * @param list<int> $capacitacionIds
     * @return array<string, list<array<string,mixed>>> clave "capacitacionId:mes"
     */
    private function sesionesPorCapacitacionMes(array $capacitacionIds, int $anio): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $capacitacionIds))));
        if ($ids === []) {
            return [];
        }
        $mapa = [];
        foreach ($this->sesionService->resumir($this->sesiones->listarPorCapacitacionesAnio($ids, $anio)) as $sesion) {
            $capId = (int)($sesion['capacitacion_id'] ?? 0);
            $fecha = (string)($sesion['fecha'] ?? $sesion['fecha_hora'] ?? '');
            $mes = strlen($fecha) >= 7 ? (int)substr($fecha, 5, 2) : 0;
            if ($capId < 1 || $mes < 1) {
                continue;
            }
            $mapa[$capId . ':' . $mes][] = $sesion;
        }

        return $mapa;
    }

    private function nombreMes(int $mes): string
    {
        $nombres = [
            1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
            5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
            9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre',
        ];

        return $nombres[$mes] ?? (string)$mes;
    }
}
