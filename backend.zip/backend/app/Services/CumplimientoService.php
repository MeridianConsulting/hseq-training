<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Exceptions\HttpException;
use App\Core\Logger;
use App\Repositories\AlertaRepository;
use App\Repositories\AsignacionRepository;
use App\Repositories\CapacitacionRepository;
use App\Repositories\CumplimientoRepository;
use App\Repositories\MatrizRepository;
use App\Repositories\PersonalRepository;
use PDOException;
use Throwable;

class CumplimientoService
{
    public const RESULTADO_APROBADO = 'APROBADO';
    public const MENSAJE_YA_REGISTRADO = 'El cumplimiento ya fue registrado.';
    public const MENSAJE_NOTA_OBLIGATORIA = 'La nota es obligatoria.';
    public const MENSAJE_NOTA_NUMERICA = 'La nota debe ser numérica.';
    public const MENSAJE_NOTA_RANGO = 'La nota está fuera del rango permitido.';
    public const MENSAJE_NOTA_NO_REQUERIDA = 'Esta capacitación no requiere evaluación.';
    public const MENSAJE_NOTA_MINIMA = 'La nota no alcanza la mínima aprobatoria.';
    public const NOTA_MIN = 0.0;
    public const NOTA_MAX = 5.0;

    public const MENSAJE_CONSULTA = 'No fue posible consultar la información de cumplimientos.';
    public const MENSAJE_CORPORATIVA = 'No fue posible consultar la base corporativa de personal.';

    private const SQLSTATE_INTEGRIDAD = '23000';
    private const ASISTENCIAS_VALIDAS = ['ASISTIO', 'TARDE'];

    private CumplimientoRepository $repo;
    private VencimientoService $vencimiento;
    private SoporteService $soportes;
    private AuditoriaService $auditoria;

    /** @var array<string,string> */
    public const CAMPOS_AUDITABLES = [
        'fecha_realizacion' => 'Fecha de realización',
        'resultado' => 'Resultado',
        'horas_efectivas' => 'Horas efectivas',
        'fecha_vencimiento' => 'Fecha de vencimiento',
        'observaciones' => 'Observaciones',
        'nota_evaluacion' => 'Nota de evaluación',
    ];

    public function __construct()
    {
        $this->repo = new CumplimientoRepository();
        $this->vencimiento = new VencimientoService();
        $this->soportes = new SoporteService();
        $this->auditoria = new AuditoriaService();
    }

    public function reglasIndividual(): array
    {
        return [
            'asignacion_id' => 'required|integer|min:1',
            'sesion_id' => 'required|integer|min:1',
            'fecha_realizacion' => 'required|date',
            'resultado' => 'required|in:' . self::RESULTADO_APROBADO,
            'horas_efectivas' => 'required|numeric|gt:0',
            'observaciones' => 'nullable|string|max:500',
            'nota_evaluacion' => 'nullable',
        ];
    }

    public function reglasMasivo(): array
    {
        return [
            'sesion_id' => 'required|integer|min:1',
            'asignacion_ids' => 'required|array',
            'fecha_realizacion' => 'required|date',
            'resultado' => 'required|in:' . self::RESULTADO_APROBADO,
            'horas_efectivas' => 'required|numeric|gt:0',
            'observaciones' => 'nullable|string|max:500',
            'notas' => 'nullable',
        ];
    }

    public function reglasEditar(): array
    {
        return [
            'fecha_realizacion' => 'required|date',
            'resultado' => 'nullable|in:' . self::RESULTADO_APROBADO,
            'horas_efectivas' => 'required|numeric|gt:0',
            'observaciones' => 'nullable|string|max:500',
            'nota_evaluacion' => 'nullable',
            'fecha_vencimiento' => 'nullable|date',
        ];
    }

    public function reglasEvaluaciones(): array
    {
        return [
            'sesion_id' => 'required|integer|min:1',
            'items' => 'required|array',
        ];
    }

    public function mensajes(): array
    {
        return [
            'fecha_realizacion.required' => 'La fecha de realización es obligatoria.',
            'fecha_realizacion.date' => 'La fecha de realización no es válida.',
            'resultado.required' => 'El resultado es obligatorio.',
            'resultado.in' => 'El resultado debe ser APROBADO.',
            'horas_efectivas.required' => 'Las horas efectivas son obligatorias.',
            'horas_efectivas.numeric' => 'Las horas efectivas deben ser un valor numérico.',
            'horas_efectivas.gt' => 'Las horas efectivas deben ser mayores que cero.',
            'fecha_vencimiento.date' => 'La fecha de vencimiento no es válida.',
            'asignacion_id.required' => 'Debe indicar la asignación.',
            'sesion_id.required' => 'Debe indicar la sesión.',
            'asignacion_ids.required' => 'Debe seleccionar al menos un trabajador.',
            'items.required' => 'Debe indicar las evaluaciones.',
            'nota_evaluacion.required' => self::MENSAJE_NOTA_OBLIGATORIA,
        ];
    }

    /**
     * @param array{persona_id?:?int, sesion_id?:?int, buscar?:?string, evidencia_faltante?:?int} $filtros
     */
    public function listar(int $pagina, int $porPagina, array $filtros): array
    {
        $pagina = max(1, $pagina);
        $porPagina = min(100, max(1, $porPagina));
        $offset = ($pagina - 1) * $porPagina;

        $filas = $this->repo->listar($porPagina, $offset, $filtros);
        $items = $this->normalizarConSoportes($filas);

        return [
            'items' => $items,
            'total' => $this->repo->contar($filtros),
            'page' => $pagina,
            'per_page' => $porPagina,
        ];
    }

    public function ver(int $id): array
    {
        $fila = $this->repo->buscarPorId($id);
        if ($fila === null) {
            throw new HttpException('El cumplimiento no existe.', 404);
        }

        return $this->normalizarConSoportes([$fila])[0];
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array{items:list<array<string,mixed>>,total:int,page:int,per_page:int}
     */
    public function consultar(int $pagina, int $porPagina, array $filtros): array
    {
        $pagina = max(1, $pagina);
        $porPagina = min(100, max(1, $porPagina));
        $offset = ($pagina - 1) * $porPagina;
        $filtros = $this->aplicarPeriodoAFiltros($filtros);

        try {
            $filas = $this->repo->consultar($porPagina, $offset, $filtros);
            $items = $this->normalizarConsultaConSoportes($filas);

            return [
                'items' => $items,
                'total' => $this->repo->contarConsulta($filtros),
                'page' => $pagina,
                'per_page' => $porPagina,
            ];
        } catch (HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            $this->falloConsulta($e);
        }
    }

    /**
     * Consolidado por capacitación. Ejecutadas = resultado APROBADO (alineado a Panel).
     * Fuera de tiempo se cuenta aparte; no reduce el porcentaje (fórmula pendiente).
     *
     * @param array<string,mixed> $filtros
     * @return array{periodo:array<string,mixed>,items:list<array<string,mixed>>,total:int,totales:array<string,int>}
     */
    public function consultarPorCapacitacion(array $filtros): array
    {
        if (!isset($filtros['tipo']) || $filtros['tipo'] === null || $filtros['tipo'] === '') {
            $filtros['tipo'] = 'mensual';
        }
        if (!isset($filtros['anio']) || $filtros['anio'] === null || $filtros['anio'] === '') {
            $filtros['anio'] = (int)date('Y');
        }
        if (($filtros['tipo'] ?? '') === 'mensual' && (!isset($filtros['mes']) || $filtros['mes'] === null || $filtros['mes'] === '')) {
            $filtros['mes'] = (int)date('n');
        }
        $filtros = $this->aplicarPeriodoAFiltros($filtros);
        $periodo = (new DashboardService())->periodo([
            'tipo' => $filtros['tipo'] ?? 'mensual',
            'anio' => $filtros['anio'] ?? (int)date('Y'),
            'mes' => $filtros['mes'] ?? null,
            'trimestre' => $filtros['trimestre'] ?? null,
            'semestre' => $filtros['semestre'] ?? null,
        ]);

        try {
            $filas = $this->repo->consultarPorCapacitacion($filtros);
            $items = [];
            $totales = [
                'programadas' => 0,
                'ejecutadas' => 0,
                'pendientes' => 0,
                'ejecutadas_fuera_de_tiempo' => 0,
            ];
            foreach ($filas as $fila) {
                $programadas = (int)($fila['programadas'] ?? 0);
                $ejecutadas = (int)($fila['ejecutadas'] ?? 0);
                $pendientes = (int)($fila['pendientes'] ?? 0);
                $fuera = (int)($fila['ejecutadas_fuera_de_tiempo'] ?? 0);
                $totales['programadas'] += $programadas;
                $totales['ejecutadas'] += $ejecutadas;
                $totales['pendientes'] += $pendientes;
                $totales['ejecutadas_fuera_de_tiempo'] += $fuera;
                $items[] = [
                    'capacitacion_id' => (int)$fila['capacitacion_id'],
                    'codigo' => (string)($fila['capacitacion_codigo'] ?? ''),
                    'nombre' => (string)($fila['capacitacion_nombre'] ?? ''),
                    'tipo_nombre' => $fila['tipo_nombre'] ?? null,
                    'es_tarea_critica' => (int)($fila['es_tarea_critica'] ?? 0) === 1,
                    'vigencia_nombre' => humanizar_nombre_unidad($fila['vigencia_nombre'] ?? null),
                    'programadas' => $programadas,
                    'ejecutadas' => $ejecutadas,
                    'pendientes' => $pendientes,
                    'ejecutadas_fuera_de_tiempo' => $fuera,
                    'pendientes_fuera_plazo' => (int)($fila['pendientes_fuera_plazo'] ?? 0),
                    'vigentes' => (int)($fila['vigentes'] ?? 0),
                    'vencidas_vigencia' => (int)($fila['vencidas_vigencia'] ?? 0),
                    'fecha_desde' => isset($fila['fecha_desde']) && $fila['fecha_desde'] !== null
                        ? substr((string)$fila['fecha_desde'], 0, 10)
                        : null,
                    'fecha_hasta' => isset($fila['fecha_hasta']) && $fila['fecha_hasta'] !== null
                        ? substr((string)$fila['fecha_hasta'], 0, 10)
                        : null,
                ];
            }

            return [
                'periodo' => $periodo,
                'items' => $items,
                'total' => count($items),
                'totales' => $totales,
            ];
        } catch (HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            $this->falloConsulta($e);
        }
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array<string,mixed>
     */
    private function aplicarPeriodoAFiltros(array $filtros): array
    {
        $tipo = $filtros['tipo'] ?? null;
        if (!is_string($tipo) || $tipo === '') {
            return $filtros;
        }

        $periodo = (new DashboardService())->periodo([
            'tipo' => $tipo,
            'anio' => $filtros['anio'] ?? (int)date('Y'),
            'mes' => $filtros['mes'] ?? null,
            'trimestre' => $filtros['trimestre'] ?? null,
            'semestre' => $filtros['semestre'] ?? null,
        ]);
        $filtros['anio'] = (int)$periodo['anio'];
        $filtros['meses'] = $periodo['meses'];
        $filtros['tipo'] = $periodo['tipo'];
        $filtros['mes'] = $periodo['mes'] ?? ($filtros['mes'] ?? null);
        $filtros['trimestre'] = $periodo['trimestre'] ?? ($filtros['trimestre'] ?? null);
        $filtros['semestre'] = $periodo['semestre'] ?? ($filtros['semestre'] ?? null);

        return $filtros;
    }

    /**
     * @return array<string,mixed>
     */
    public function consultarDetalle(int $asignacionId): array
    {
        try {
            $fila = $this->repo->consultarPorAsignacion($asignacionId);
        } catch (Throwable $e) {
            $this->falloConsulta($e);
        }

        if ($fila === null) {
            throw new HttpException('La asignación no existe.', 404);
        }

        $item = $this->normalizarConsultaConSoportes([$fila])[0];
        $asistencia = $this->repo->ultimaAsistencia($asignacionId);
        $programacion = $this->repo->programacionAsignacion($asignacionId);
        $matrizId = (int)($fila['matriz_aplicabilidad_id'] ?? 0);
        $regla = $matrizId > 0 ? $this->repo->reglaMatriz($matrizId) : null;
        if ($regla === null) {
            $cargoSnap = isset($fila['cargo_id_ext']) ? (int)$fila['cargo_id_ext'] : 0;
            $proyectoSnap = is_string($fila['proyecto'] ?? null) ? (string)$fila['proyecto'] : null;
            $regla = $this->repo->reglaMatrizPorContexto(
                (int)$fila['capacitacion_id'],
                $cargoSnap > 0 ? $cargoSnap : null,
                $proyectoSnap
            );
            if (is_array($regla)) {
                $matrizId = (int)($regla['matriz_aplicabilidad_id'] ?? 0);
            }
        }
        $periodicidad = $this->vencimiento->resolverPeriodicidad($asignacionId);

        $fechaSesion = null;
        $asistenciaEstado = null;
        $sesionId = $item['sesion_id'] ?? null;
        if (is_array($asistencia)) {
            $fechaSesion = $asistencia['fecha_sesion'] ?? null;
            $asistenciaEstado = $asistencia['estado_asistencia'] ?? null;
            if ($sesionId === null && isset($asistencia['sesion_id'])) {
                $sesionId = (int)$asistencia['sesion_id'];
            }
        }

        $fechaProgramada = null;
        $fuenteProgramacion = 'Asignaciones';
        if (!empty($item['fecha_limite_cumplimiento'])) {
            $fechaProgramada = substr((string)$item['fecha_limite_cumplimiento'], 0, 10);
        } elseif (is_array($programacion)
            && isset($programacion['anio'], $programacion['mes_programado'])
            && $programacion['mes_programado'] !== null
            && $programacion['mes_programado'] !== ''
        ) {
            $mes = str_pad((string)(int)$programacion['mes_programado'], 2, '0', STR_PAD_LEFT);
            $fechaProgramada = (int)$programacion['anio'] . '-' . $mes;
            $fuenteProgramacion = 'Plan anual (informativo)';
        }

        $fuentes = [
            'aplicabilidad' => 'Matriz',
            'obligacion' => 'Asignaciones',
            'fecha_programada' => $fuenteProgramacion,
            'ejecucion' => 'Sesión',
            'asistencia' => 'Sesiones y asistencia',
            'evaluacion' => 'Evaluación',
            'soportes' => 'Evidencias',
            'vigencia' => 'Capacitaciones',
        ];

        return [
            'asignacion' => $item,
            'trabajador' => [
                'persona_id_ext' => $item['persona_id_ext'],
                'nombre' => $item['persona_nombre'],
                'documento' => $item['numero_documento'],
                'cargo' => $item['cargo'],
                'proyecto' => $item['proyecto'],
                'estado_laboral' => $item['estado_laboral'],
            ],
            'capacitacion' => [
                'capacitacion_id' => $item['capacitacion_id'],
                'codigo' => $item['capacitacion_codigo'],
                'nombre' => $item['capacitacion_nombre'],
                'requiere_evaluacion' => $item['requiere_evaluacion'],
                'nota_minima' => $item['nota_minima'],
                'requiere_certificado' => $item['requiere_certificado'],
                'requiere_listado_asistencia' => $item['requiere_listado_asistencia'],
                'es_tarea_critica' => $item['es_tarea_critica'],
                'vigencia_nombre' => humanizar_nombre_unidad($item['vigencia_nombre'] ?? null),
                'tipo_nombre' => $item['tipo_nombre'],
            ],
            'aplicabilidad' => [
                'aplica' => $regla !== null,
                'matriz_aplicabilidad_id' => $matrizId > 0 ? $matrizId : null,
                'activa' => $regla !== null ? (int)($regla['activa'] ?? 0) === 1 : null,
                'obligatoria' => $regla !== null ? (int)($regla['obligatoria'] ?? 0) === 1 : null,
                'proceso_nombre' => $regla['proceso_nombre'] ?? $item['proceso_nombre'],
                'proyecto' => $regla['proyecto'] ?? $item['proyecto'],
                'fuente' => $fuentes['aplicabilidad'],
            ],
            'obligacion' => [
                'asignacion_id' => $item['asignacion_id'],
                'origen' => $item['origen'],
                'fecha_asignacion' => $item['fecha_asignacion'],
                'fecha_limite_cumplimiento' => $item['fecha_limite_cumplimiento'],
                'fuente' => $fuentes['obligacion'],
            ],
            'programacion' => [
                'fecha_programada' => $fechaProgramada,
                'fecha_desde' => $item['fecha_asignacion'] !== null
                    ? substr((string)$item['fecha_asignacion'], 0, 10)
                    : null,
                'fecha_hasta' => !empty($item['fecha_limite_cumplimiento'])
                    ? substr((string)$item['fecha_limite_cumplimiento'], 0, 10)
                    : null,
                'fuente' => $fuentes['fecha_programada'],
            ],
            'ejecucion' => [
                'sesion_id' => $sesionId,
                'fecha_sesion' => $fechaSesion,
                'fecha_realizacion' => $item['fecha_realizacion'],
                'fuera_de_tiempo' => $this->ejecutadaFueraDeTiempo(
                    $item['fecha_realizacion'] ?? null,
                    $item['fecha_limite_cumplimiento'] ?? null
                ),
                'fuente' => $fuentes['ejecucion'],
            ],
            'asistencia' => [
                'estado' => $asistenciaEstado,
                'valida' => in_array((string)$asistenciaEstado, self::ASISTENCIAS_VALIDAS, true),
                'fuente' => $fuentes['asistencia'],
            ],
            'evaluacion' => [
                'requiere' => $item['requiere_evaluacion'],
                'nota_obtenida' => $item['nota_evaluacion'],
                'nota_minima' => $item['nota_minima'],
                'aprobada' => $item['evaluacion_aprobada'],
                'fuente' => $fuentes['evaluacion'],
            ],
            'soportes' => [
                'requiere_certificado' => $item['requiere_certificado'],
                'requiere_listado' => $item['requiere_listado_asistencia'],
                'items' => $item['soportes'],
                'fuente' => $fuentes['soportes'],
            ],
            'vigencia' => [
                'nombre' => humanizar_nombre_unidad($item['vigencia_nombre'] ?? null),
                'fecha_vencimiento' => $item['fecha_vencimiento'],
                'periodicidad_nombre' => humanizar_nombre_unidad($periodicidad['nombre'] ?? null),
                'origen_periodicidad' => $periodicidad['origen'] ?? null,
                'fuente' => $fuentes['vigencia'],
            ],
            'estado_actual' => $item['estado_calculado'],
            'ejecutada_fuera_de_tiempo' => $this->ejecutadaFueraDeTiempo(
                $item['fecha_realizacion'] ?? null,
                $item['fecha_limite_cumplimiento'] ?? null
            ),
        ];
    }

    /**
     * @return array{trabajador:array<string,mixed>,aplicables:list<array<string,mixed>>,items:list<array<string,mixed>>}
     */
    public function consultarTrabajador(int $personaId): array
    {
        if ($personaId < 1) {
            throw new HttpException('El trabajador no es válido.', 422);
        }

        try {
            $consulta = $this->consultar(1, 100, ['persona_id' => $personaId, 'estado_laboral' => null]);
        } catch (HttpException $e) {
            throw $e;
        }

        $trabajador = [
            'persona_id_ext' => $personaId,
            'nombre' => null,
            'documento' => null,
            'cargo' => null,
            'proyecto' => null,
            'estado_laboral' => null,
        ];

        try {
            $ficha = (new PersonalRepository())->buscarPorId($personaId);
            if (is_array($ficha)) {
                $trabajador = [
                    'persona_id_ext' => $personaId,
                    'nombre' => $ficha['nombre_completo'] ?? null,
                    'documento' => $ficha['numero_documento'] ?? null,
                    'cargo' => $ficha['cargo'] ?? null,
                    'proyecto' => $ficha['proyecto'] ?? null,
                    'estado_laboral' => $ficha['estado'] ?? null,
                    'cargo_id' => isset($ficha['cargo_id']) ? (int)$ficha['cargo_id'] : null,
                ];
            }
        } catch (Throwable $e) {
            $this->falloConsulta($e, self::MENSAJE_CORPORATIVA);
        }

        if ($trabajador['nombre'] === null && $consulta['items'] !== []) {
            $primero = $consulta['items'][0];
            $trabajador['nombre'] = $primero['persona_nombre'];
            $trabajador['documento'] = $primero['numero_documento'];
            $trabajador['cargo'] = $primero['cargo'];
            $trabajador['proyecto'] = $primero['proyecto'];
            $trabajador['estado_laboral'] = $primero['estado_laboral'];
        }

        if ($trabajador['nombre'] === null && $consulta['items'] === []) {
            throw new HttpException('El trabajador no existe en la base corporativa.', 404);
        }

        $aplicables = [];
        $cargoId = isset($trabajador['cargo_id']) ? (int)$trabajador['cargo_id'] : 0;
        $proyecto = is_string($trabajador['proyecto'] ?? null) ? trim((string)$trabajador['proyecto']) : '';
        $proyectoFiltro = $proyecto !== '' ? $proyecto : null;
        $procesoIds = [];
        foreach ($trabajador['procesos'] ?? [] as $proc) {
            if (!is_array($proc)) {
                continue;
            }
            $pid = (int)($proc['proceso_id'] ?? 0);
            if ($pid > 0) {
                $procesoIds[$pid] = $pid;
            }
        }
        try {
            $matrizRepo = new MatrizRepository();
            if ($procesoIds === [] && $cargoId > 0) {
                $desdeMatriz = $matrizRepo->procesoIdParaCargo($cargoId, $proyectoFiltro);
                if ($desdeMatriz !== null && $desdeMatriz > 0) {
                    $procesoIds[$desdeMatriz] = $desdeMatriz;
                }
            }
            $vistos = [];
            if ($cargoId > 0) {
                $consultas = $procesoIds !== [] ? array_values($procesoIds) : [null];
                foreach ($consultas as $procesoId) {
                    foreach ($matrizRepo->aplicables($cargoId, $procesoId, $proyectoFiltro) as $fila) {
                        if ($procesoId === null) {
                            $procesoFila = $fila['proceso_id'] ?? null;
                            if ($procesoFila !== null && (int)$procesoFila > 0) {
                                continue;
                            }
                        }
                        $cid = isset($fila['capacitacion_id']) ? (int)$fila['capacitacion_id'] : 0;
                        if ($cid < 1 || isset($vistos[$cid])) {
                            continue;
                        }
                        $vistos[$cid] = true;
                        $aplicables[] = [
                            'matriz_aplicabilidad_id' => isset($fila['matriz_aplicabilidad_id'])
                                ? (int)$fila['matriz_aplicabilidad_id']
                                : null,
                            'capacitacion_id' => $cid,
                            'capacitacion_codigo' => $fila['capacitacion_codigo'] ?? $fila['codigo'] ?? null,
                            'capacitacion_nombre' => $fila['capacitacion_nombre'] ?? $fila['nombre'] ?? null,
                            'proceso_nombre' => $fila['proceso_nombre'] ?? null,
                            'proyecto' => $fila['proyecto'] ?? null,
                        ];
                    }
                }
            }
        } catch (Throwable $e) {
            Logger::error('Error al consultar aplicables en cumplimientos: ' . $e->getMessage());
        }

        return [
            'trabajador' => $trabajador,
            'aplicables' => $aplicables,
            'items' => $consulta['items'],
        ];
    }

    /**
     * @return array{procesos:list<array<string,mixed>>,proyectos:list<string>,cargos:list<array<string,mixed>>,tipos:list<array<string,mixed>>,capacitaciones:list<array<string,mixed>>}
     */
    public function opcionesConsulta(): array
    {
        try {
            $alertas = new AlertaRepository();
            $cargos = [];
            foreach ($alertas->cargos() as $fila) {
                $cargos[] = [
                    'cargo_id' => (int)$fila['cargo_id'],
                    'nombre_cargo' => (string)$fila['nombre_cargo'],
                ];
            }

            $tipos = [];
            foreach (
                $this->repoDbTipos() as $fila
            ) {
                $tipos[] = [
                    'tipo_capacitacion_id' => (int)$fila['tipo_capacitacion_id'],
                    'nombre' => (string)$fila['nombre'],
                ];
            }

            $caps = [];
            foreach ((new \App\Repositories\CapacitacionRepository())->listarActivasResumen() as $cap) {
                $caps[] = [
                    'capacitacion_id' => $cap['capacitacion_id'],
                    'codigo' => $cap['codigo'],
                    'nombre' => $cap['nombre'],
                ];
            }

            return [
                'procesos' => $alertas->procesosActivos(),
                'proyectos' => $alertas->proyectos(),
                'cargos' => $cargos,
                'tipos' => $tipos,
                'capacitaciones' => $caps,
            ];
        } catch (Throwable $e) {
            $this->falloConsulta($e, self::MENSAJE_CORPORATIVA);
        }
    }

    /**
     * @return list<array<string,mixed>>
     */
    private function repoDbTipos(): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT tipo_capacitacion_id, nombre FROM tipos_capacitacion ORDER BY nombre ASC'
        );
    }

    /**
     * @param list<array<string,mixed>> $filas
     * @return list<array<string,mixed>>
     */
    private function normalizarConsultaConSoportes(array $filas): array
    {
        $ids = [];
        foreach ($filas as $fila) {
            if (!empty($fila['cumplimiento_id'])) {
                $ids[] = (int)$fila['cumplimiento_id'];
            }
        }
        $por = $this->soportes->porCumplimientos($ids);
        $items = [];
        foreach ($filas as $fila) {
            $cid = (int)($fila['cumplimiento_id'] ?? 0);
            $fila['soportes'] = $por[$cid] ?? [];
            $items[] = $this->normalizarConsulta($fila);
        }

        return $items;
    }

    /**
     * @param array<string,mixed> $fila
     * @return array<string,mixed>
     */
    private function normalizarConsulta(array $fila): array
    {
        $soportes = is_array($fila['soportes'] ?? null) ? $fila['soportes'] : [];
        $requiereEval = (int)($fila['capacitacion_evaluacion'] ?? 0) === 1;
        $notaMinima = round((float)($fila['capacitacion_nota_minima'] ?? 0), 2);
        $nota = $fila['nota_evaluacion'] !== null ? (float)$fila['nota_evaluacion'] : null;

        return [
            'asignacion_id' => (int)$fila['asignacion_id'],
            'persona_id_ext' => (int)$fila['persona_id_ext'],
            'persona_nombre' => $fila['persona_nombre'] ?? null,
            'numero_documento' => $fila['numero_documento'] ?? null,
            'cargo' => $fila['cargo'] ?? null,
            'proyecto' => $fila['proyecto'] ?? null,
            'estado_laboral' => $fila['estado_laboral'] ?? null,
            'proceso_id' => isset($fila['proceso_id']) && $fila['proceso_id'] !== null
                ? (int)$fila['proceso_id']
                : null,
            'proceso_nombre' => $fila['proceso_nombre'] ?? null,
            'capacitacion_id' => (int)$fila['capacitacion_id'],
            'capacitacion_codigo' => $fila['capacitacion_codigo'] ?? null,
            'capacitacion_nombre' => $fila['capacitacion_nombre'] ?? null,
            'tipo_nombre' => $fila['tipo_nombre'] ?? null,
            'es_tarea_critica' => (int)($fila['es_tarea_critica'] ?? 0) === 1,
            'origen' => $fila['origen'] ?? null,
            'fecha_asignacion' => $fila['fecha_asignacion'] ?? null,
            'fecha_limite_cumplimiento' => $fila['fecha_limite_cumplimiento'] ?? null,
            'cumplimiento_id' => isset($fila['cumplimiento_id']) && $fila['cumplimiento_id'] !== null
                ? (int)$fila['cumplimiento_id']
                : null,
            'sesion_id' => isset($fila['sesion_id']) && $fila['sesion_id'] !== null
                ? (int)$fila['sesion_id']
                : null,
            'fecha_realizacion' => $fila['fecha_realizacion'] ?? null,
            'fecha_vencimiento' => $fila['fecha_vencimiento'] ?? null,
            'estado_asistencia' => $fila['estado_asistencia'] ?? null,
            'ejecutada_fuera_de_tiempo' => $this->ejecutadaFueraDeTiempo(
                $fila['fecha_realizacion'] ?? null,
                $fila['fecha_limite_cumplimiento'] ?? null
            ),
            'resultado' => $fila['resultado'] ?? null,
            'horas_efectivas' => $fila['horas_efectivas'] !== null ? (float)$fila['horas_efectivas'] : null,
            'requiere_evaluacion' => $requiereEval,
            'nota_minima' => $notaMinima,
            'nota_evaluacion' => $nota,
            'evaluacion_aprobada' => $this->evaluacionAprobada($nota, $requiereEval, $notaMinima),
            'requiere_certificado' => (int)($fila['capacitacion_certificado'] ?? 0) === 1,
            'requiere_listado_asistencia' => (int)($fila['requiere_listado_asistencia'] ?? 0) === 1,
            'vigencia_nombre' => humanizar_nombre_unidad($fila['vigencia_nombre'] ?? null),
            'estado_calculado' => strtoupper((string)($fila['estado_calculado'] ?? '')),
            'soportes' => $soportes,
            'soportes_count' => count($soportes),
        ];
    }

    private function falloConsulta(Throwable $e, string $mensaje = self::MENSAJE_CONSULTA): void
    {
        if ($e instanceof HttpException) {
            throw $e;
        }

        Logger::error($mensaje . ': ' . $e->getMessage());
        throw new HttpException($mensaje, $e instanceof PDOException ? 503 : 500);
    }

    /**
     * @param list<int> $asignacionIds
     * @return array<string,mixed>
     */
    public function previsualizar(int $sesionId, array $asignacionIds, ?string $fechaRealizacion): array
    {
        $sesion = $this->exigirSesion($sesionId, true);
        $fecha = $this->fechaRealizacion($fechaRealizacion, $sesion);
        $ids = $this->normalizarIds($asignacionIds);

        if ($ids === []) {
            throw new HttpException('Debe seleccionar al menos un trabajador.', 422);
        }

        $items = [];
        $clavesPer = [];
        foreach ($ids as $asignacionId) {
            $preview = $this->previewDe($sesionId, $asignacionId, $fecha);
            $items[] = $preview;
            $clave = ($preview['periodicidad_cantidad'] ?? 'x') . ':' . ($preview['periodicidad_unidad'] ?? '');
            $clavesPer[$clave] = true;
        }

        $distintas = count($clavesPer) > 1;

        return [
            'sesion_id' => $sesionId,
            'fecha_realizacion' => $fecha,
            'items' => $items,
            'periodicidades_distintas' => $distintas,
            'aviso' => $distintas
                ? 'Hay más de una periodicidad en el lote. El vencimiento se calcula por trabajador.'
                : null,
        ];
    }

    /**
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function registrar(array $datos, ?int $usuarioId, ?array $actor = null): array
    {
        $datos = $this->ignorarCliente($datos);
        unset($datos['fecha_vencimiento']);
        $campos = $this->exigirCampos($datos, false);
        $campos['nota_evaluacion'] = array_key_exists('nota_evaluacion', $datos)
            ? $datos['nota_evaluacion']
            : null;
        $campos['nota_enviada'] = array_key_exists('nota_evaluacion', $datos);

        return $this->repo->transaccion(function () use ($campos, $usuarioId, $actor): array {
            $this->completarUno($campos, $usuarioId);
            $fila = $this->repo->buscarPorAsignacion((int)$campos['asignacion_id']);
            $normalizado = $fila === null ? [] : $this->normalizarConSoportes([$fila])[0];
            if ($actor !== null && $normalizado !== []) {
                $this->auditoria->deActor(
                    $actor,
                    'crear',
                    'cumplimientos_capacitacion',
                    (int)$normalizado['cumplimiento_id'],
                    [
                        'origen' => AuditoriaService::ORIGEN_SISTEMA,
                        'fecha_realizacion' => $normalizado['fecha_realizacion'] ?? null,
                        'resultado' => $normalizado['resultado'] ?? null,
                        'horas_efectivas' => $normalizado['horas_efectivas'] ?? null,
                        'fecha_vencimiento' => $normalizado['fecha_vencimiento'] ?? null,
                    ]
                );
            }

            return $normalizado;
        });
    }

    public function reglasHistorial(): array
    {
        return [
            'persona_id' => 'required|integer|min:1',
            'capacitacion_id' => 'required|integer|min:1',
            'fecha_realizacion' => 'required|date',
            'nota_evaluacion' => 'nullable',
            'horas_efectivas' => 'nullable|numeric|gt:0',
            'observaciones' => 'nullable|string|max:500',
        ];
    }

    /**
     * Historial sin sesión: contenedor FK (fecha límite = realización) + cumplimiento.
     * Misma lógica que carga inicial. No programa Fecha Desde/Hasta operativas.
     *
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array<string,mixed>
     */
    public function registrarHistorial(array $datos, ?int $usuarioId, ?array $actor = null): array
    {
        $personaId = (int)($datos['persona_id'] ?? 0);
        $capId = (int)($datos['capacitacion_id'] ?? 0);
        $fecha = trim((string)($datos['fecha_realizacion'] ?? ''));
        if ($personaId < 1 || $capId < 1 || $fecha === '') {
            throw new HttpException('Debe indicar trabajador, capacitación y fecha real de ejecución.', 422);
        }

        $caps = new CapacitacionRepository();
        $cap = $caps->buscarPorId($capId);
        if ($cap === null) {
            throw new HttpException('Capacitación no encontrada.', 404);
        }

        $requiereEval = (int)($cap['evaluacion'] ?? 0) === 1;
        $notaMinima = round((float)($cap['nota_minima'] ?? 0), 2);
        $nota = null;
        if (array_key_exists('nota_evaluacion', $datos) && $datos['nota_evaluacion'] !== null && $datos['nota_evaluacion'] !== '') {
            $nota = $this->exigirNota($datos['nota_evaluacion']);
        }
        if ($requiereEval && $nota === null) {
            throw new HttpException(self::MENSAJE_NOTA_OBLIGATORIA, 422);
        }
        if ($requiereEval && $nota !== null && $nota < $notaMinima) {
            throw new HttpException(self::MENSAJE_NOTA_MINIMA, 422);
        }

        if ($this->repo->existeEjecucion($personaId, $capId, $fecha)) {
            throw new HttpException(
                'Ya existe una ejecución histórica equivalente (trabajador + capacitación + fecha).',
                409
            );
        }

        $personal = new PersonalService();
        try {
            $persona = $personal->ver($personaId);
        } catch (HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            throw new HttpException(self::MENSAJE_CORPORATIVA, $e instanceof PDOException ? 503 : 500);
        }

        $horas = $datos['horas_efectivas'] ?? null;
        if ($horas === null || $horas === '' || (float)$horas <= 0) {
            $horas = $cap['duracion_estimada_horas'] !== null
                ? (float)$cap['duracion_estimada_horas']
                : 0;
        } else {
            $horas = $this->exigirHoras($horas);
        }
        if ((float)$horas <= 0) {
            throw new HttpException('Las horas efectivas deben ser mayores que cero. Defínalas en el catálogo o en el registro.', 422);
        }

        $vence = VencimientoService::calcularFechaVencimiento(
            $fecha,
            $cap['vigencia_cantidad'] !== null ? (int)$cap['vigencia_cantidad'] : null,
            $cap['vigencia_unidad'] !== null ? (string)$cap['vigencia_unidad'] : null
        );

        $obs = trim((string)($datos['observaciones'] ?? ''));
        $origenObs = trim((string)($datos['origen_observacion'] ?? ''));
        if ($origenObs === '') {
            $origenObs = 'Registro histórico manual. Contenedor FK (fecha límite = realización); no programa el futuro.';
        }
        if ($obs !== '') {
            $origenObs .= ' ' . $obs;
        }

        return $this->repo->transaccion(function () use (
            $personaId,
            $capId,
            $fecha,
            $persona,
            $horas,
            $nota,
            $vence,
            $origenObs,
            $usuarioId,
            $actor
        ): array {
            $asigId = (new AsignacionRepository())->crear([
                'persona_id_ext' => $personaId,
                'contrato_id_ext' => $persona['contrato_id'] ?? null,
                'capacitacion_id' => $capId,
                'matriz_aplicabilidad_id' => null,
                'fecha_asignacion' => $fecha,
                'fecha_limite_cumplimiento' => $fecha,
                'origen' => 'MANUAL',
                'cargo_id_ext' => $persona['cargo_id'] ?? null,
                'area_id' => null,
                'proceso_id' => null,
                'ambito' => null,
                'proyecto' => $persona['proyecto'] ?? null,
                'creada_por_usuario_id_ext' => $usuarioId,
            ]);

            $cumplimientoId = $this->repo->crear([
                'asignacion_id' => $asigId,
                'sesion_id' => null,
                'fecha_realizacion' => $fecha,
                'resultado' => self::RESULTADO_APROBADO,
                'horas_efectivas' => (float)$horas,
                'nota_evaluacion' => $nota,
                'observaciones' => $origenObs,
                'fecha_vencimiento' => $vence,
                'registrado_por_usuario_id_ext' => $usuarioId,
            ]);

            $fila = $this->repo->buscarPorAsignacion($asigId);
            $normalizado = $fila === null ? [] : $this->normalizarConSoportes([$fila])[0];
            if ($actor !== null && $normalizado !== []) {
                $this->auditoria->deActor(
                    $actor,
                    'crear',
                    'cumplimientos_capacitacion',
                    $cumplimientoId,
                    [
                        'origen' => AuditoriaService::ORIGEN_USUARIO,
                        'modo' => 'historial',
                        'persona_id_ext' => $personaId,
                        'capacitacion_id' => $capId,
                        'fecha_realizacion' => $fecha,
                        'fecha_vencimiento' => $vence,
                        'nota' => 'Historial real. No programa Fecha Desde/Hasta.',
                    ]
                );
            }

            return $normalizado;
        });
    }

    /**
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array{procesados:int,completados:int,errores:int,items:list<array<string,mixed>>,errores_detalle:list<array<string,mixed>>}
     */
    public function registrarMasivo(array $datos, ?int $usuarioId, ?array $actor = null): array
    {
        $datos = $this->ignorarCliente($datos);
        unset($datos['fecha_vencimiento']);
        $sesionId = (int)($datos['sesion_id'] ?? 0);
        $sesion = $this->exigirSesion($sesionId, true);
        $fecha = $this->fechaRealizacion($datos['fecha_realizacion'] ?? null, null);
        $resultado = $this->exigirResultado($datos['resultado'] ?? null);
        $horas = $this->exigirHoras($datos['horas_efectivas'] ?? null);
        $observaciones = nullable_trimmed_string($datos['observaciones'] ?? null);
        $ids = $this->normalizarIds($datos['asignacion_ids'] ?? []);
        $notas = $this->mapaNotas($datos['notas'] ?? []);
        $requiereEval = (int)($sesion['capacitacion_evaluacion'] ?? 0) === 1;
        $minima = round((float)($sesion['capacitacion_nota_minima'] ?? 0), 2);

        if ($ids === []) {
            throw new HttpException('Debe seleccionar al menos un trabajador.', 422);
        }
        if ($requiereEval) {
            foreach ($ids as $asignacionId) {
                if (!array_key_exists($asignacionId, $notas)) {
                    throw new HttpException(self::MENSAJE_NOTA_OBLIGATORIA, 422);
                }
                $this->exigirNota($notas[$asignacionId]);
            }
        } elseif ($notas !== []) {
            throw new HttpException(self::MENSAJE_NOTA_NO_REQUERIDA, 422);
        }

        $pendientes = [];
        $erroresDetalle = [];
        foreach ($ids as $asignacionId) {
            try {
                $this->validarParticipante($sesionId, $asignacionId, true);
                $pendientes[] = $asignacionId;
            } catch (HttpException $e) {
                $part = $this->repo->participanteEnSesion($sesionId, $asignacionId);
                $erroresDetalle[] = [
                    'asignacion_id' => $asignacionId,
                    'numero_documento' => $part['numero_documento'] ?? null,
                    'motivo' => $e->getMessage(),
                ];
            }
        }

        if ($erroresDetalle !== []) {
            $primero = $erroresDetalle[0];
            $status = str_contains((string)$primero['motivo'], self::MENSAJE_YA_REGISTRADO) ? 409 : 422;
            throw new HttpException((string)$primero['motivo'], $status);
        }

        $completados = [];
        try {
            $this->repo->transaccion(function () use (
                $pendientes,
                $sesionId,
                $fecha,
                $resultado,
                $horas,
                $observaciones,
                $usuarioId,
                $notas,
                $requiereEval,
                $minima,
                $actor,
                &$completados
            ): void {
                foreach ($pendientes as $asignacionId) {
                    $nota = $requiereEval ? $this->exigirNota($notas[$asignacionId] ?? null) : null;
                    $resultadoFila = $resultado;
                    if ($requiereEval && $nota < $minima) {
                        $existente = $this->repo->buscarPorAsignacion($asignacionId);
                        $actual = strtoupper((string)($existente['resultado'] ?? ''));
                        $resultadoFila = $actual !== '' && $actual !== self::RESULTADO_APROBADO
                            ? $actual
                            : 'ASISTIO';
                    }
                    $this->persistir(
                        $sesionId,
                        $asignacionId,
                        $fecha,
                        $resultadoFila,
                        $horas,
                        $observaciones,
                        $usuarioId,
                        $nota,
                        $requiereEval
                    );
                    $fila = $this->repo->buscarPorAsignacion($asignacionId);
                    if ($fila !== null) {
                        $completados[] = $fila;
                    }
                }
                if ($actor !== null && $completados !== []) {
                    $ids = [];
                    foreach ($completados as $fila) {
                        $ids[] = (int)$fila['cumplimiento_id'];
                    }
                    $this->auditoria->deActor(
                        $actor,
                        'registrar_masivo',
                        'cumplimientos_capacitacion',
                        $sesionId,
                        [
                            'origen' => AuditoriaService::ORIGEN_SISTEMA,
                            'sesion_id' => $sesionId,
                            'completados' => count($completados),
                            'cumplimiento_ids' => $ids,
                            'fecha_realizacion' => $fecha,
                        ]
                    );
                }
            });
        } catch (HttpException $e) {
            throw $e;
        } catch (PDOException $e) {
            if ($e->getCode() === self::SQLSTATE_INTEGRIDAD) {
                throw new HttpException(self::MENSAJE_YA_REGISTRADO, 409);
            }
            throw new HttpException('No fue posible registrar los cumplimientos.', 500);
        }

        return [
            'procesados' => count($ids),
            'completados' => count($completados),
            'errores' => 0,
            'items' => $this->normalizarConSoportes($completados),
            'errores_detalle' => [],
        ];
    }

    /**
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function actualizar(int $id, array $datos, ?int $usuarioId, ?array $actor = null): array
    {
        $datos = $this->ignorarCliente($datos);
        $actual = $this->repo->buscarPorId($id);
        if ($actual === null) {
            throw new HttpException('El cumplimiento no existe.', 404);
        }

        $fecha = $this->fechaRealizacion($datos['fecha_realizacion'] ?? null, null);
        $horas = $this->exigirHoras($datos['horas_efectivas'] ?? null);
        $resultadoEnviado = array_key_exists('resultado', $datos)
            && $datos['resultado'] !== null
            && $datos['resultado'] !== '';
        $resultado = $resultadoEnviado
            ? $this->exigirResultado($datos['resultado'])
            : strtoupper((string)($actual['resultado'] ?? ''));
        $notaEnviada = array_key_exists('nota_evaluacion', $datos);
        $meta = $this->metaEvaluacion($actual, (int)($actual['sesion_id'] ?? 0));
        $nota = $this->resolverNota(
            $datos['nota_evaluacion'] ?? null,
            $notaEnviada,
            $meta,
            $actual['nota_evaluacion'] ?? null
        );
        $this->exigirNotaParaAprobado($resultado, $nota, $meta);
        $this->exigirEvidenciaParaAprobado(
            $resultado,
            $actual,
            (int)($actual['sesion_id'] ?? 0),
            (int)$actual['asignacion_id']
        );
        $observaciones = nullable_trimmed_string($datos['observaciones'] ?? null);
        $venceManual = array_key_exists('fecha_vencimiento', $datos)
            && $datos['fecha_vencimiento'] !== null
            && trim((string)$datos['fecha_vencimiento']) !== '';
        $vence = $venceManual
            ? $this->exigirFechaVencimiento($datos['fecha_vencimiento'])
            : $this->vencimiento->fechaVencimientoDeAsignacion((int)$actual['asignacion_id'], $fecha);

        $campos = [
            'fecha_realizacion' => $fecha,
            'resultado' => $resultado !== '' ? $resultado : ($actual['resultado'] ?? null),
            'horas_efectivas' => $horas,
            'fecha_vencimiento' => $vence,
            'registrado_por_usuario_id_ext' => $usuarioId,
        ];
        if ($observaciones !== null || array_key_exists('observaciones', $datos)) {
            $campos['observaciones'] = $observaciones;
        }
        if ($notaEnviada || ($meta['requiere'] && $nota !== null)) {
            $campos['nota_evaluacion'] = $nota;
        }

        $antes = $this->recorteAuditable($actual);

        return $this->repo->transaccion(function () use ($id, $campos, $antes, $actor, $venceManual): array {
            $this->repo->actualizar($id, $campos);
            $despuesFila = $this->ver($id);
            if ($actor !== null) {
                $cambios = $this->auditoria->diff($antes, $despuesFila, self::CAMPOS_AUDITABLES);
                if ($cambios !== []) {
                    $venceEnDiff = false;
                    foreach ($cambios as $cambio) {
                        if (($cambio['campo'] ?? '') === 'fecha_vencimiento') {
                            $venceEnDiff = true;
                            break;
                        }
                    }
                    $origen = $venceManual || !$venceEnDiff
                        ? AuditoriaService::ORIGEN_USUARIO
                        : AuditoriaService::ORIGEN_SISTEMA;
                    $this->auditoria->deActor(
                        $actor,
                        'actualizar',
                        'cumplimientos_capacitacion',
                        $id,
                        $this->auditoria->payloadNuevo($cambios, $origen),
                        $antes
                    );
                }
            }

            return $despuesFila;
        });
    }

    public function mensajeMasivo(array $resultado): string
    {
        $n = (int)$resultado['completados'];
        if ($n === 1) {
            return '1 cumplimiento registrado.';
        }

        return "{$n} cumplimientos registrados.";
    }

    /**
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array{procesados:int,items:list<array<string,mixed>>}
     */
    public function registrarEvaluaciones(array $datos, ?int $usuarioId, ?array $actor = null): array
    {
        $sesionId = (int)($datos['sesion_id'] ?? 0);
        $sesion = $this->exigirSesion($sesionId, true);
        $requiere = (int)($sesion['capacitacion_evaluacion'] ?? 0) === 1;
        if (!$requiere) {
            throw new HttpException(self::MENSAJE_NOTA_NO_REQUERIDA, 422);
        }

        $items = is_array($datos['items'] ?? null) ? $datos['items'] : [];
        if ($items === []) {
            throw new HttpException('Debe indicar las evaluaciones.', 422);
        }

        $preparados = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $asignacionId = (int)($item['asignacion_id'] ?? 0);
            if ($asignacionId < 1) {
                throw new HttpException('Debe indicar la asignación.', 422);
            }
            $this->validarParticipante($sesionId, $asignacionId, false);
            $nota = $this->exigirNota($item['nota'] ?? $item['nota_evaluacion'] ?? null);
            $existente = $this->repo->buscarPorAsignacion($asignacionId);
            if ($existente === null) {
                throw new HttpException(
                    'Solo se puede registrar la evaluación si el trabajador asistió.',
                    422
                );
            }
            $resultado = strtoupper((string)($existente['resultado'] ?? ''));
            $minima = round((float)($sesion['capacitacion_nota_minima'] ?? 0), 2);
            if ($resultado === self::RESULTADO_APROBADO && $nota < $minima) {
                throw new HttpException(self::MENSAJE_NOTA_MINIMA, 422);
            }
            $preparados[] = [
                'cumplimiento_id' => (int)$existente['cumplimiento_id'],
                'asignacion_id' => $asignacionId,
                'nota' => $nota,
                'nota_anterior' => $existente['nota_evaluacion'] ?? null,
                'persona_id_ext' => $existente['persona_id_ext'] ?? null,
                'numero_documento' => $existente['numero_documento'] ?? null,
            ];
        }

        if ($preparados === []) {
            throw new HttpException('Debe indicar las evaluaciones.', 422);
        }

        $filas = [];
        try {
            $this->repo->transaccion(function () use ($preparados, $usuarioId, $actor, $sesionId, $sesion, &$filas): void {
                $minima = round((float)($sesion['capacitacion_nota_minima'] ?? 0), 2);
                $requiereCert = (int)($sesion['capacitacion_certificado'] ?? 0) === 1;
                foreach ($preparados as $item) {
                    $campos = [
                        'nota_evaluacion' => $item['nota'],
                        'registrado_por_usuario_id_ext' => $usuarioId,
                    ];
                    // Si la nota alcanza el mínimo y no falta certificado, el cumplimiento queda APROBADO.
                    if ((float)$item['nota'] >= $minima) {
                        $cumplimientoId = (int)$item['cumplimiento_id'];
                        $soportesOk = !$requiereCert || $this->soportes->contar($cumplimientoId) > 0;
                        if ($soportesOk) {
                            $campos['resultado'] = self::RESULTADO_APROBADO;
                        }
                    }
                    $this->repo->actualizar((int)$item['cumplimiento_id'], $campos);
                    $fila = $this->repo->buscarPorAsignacion((int)$item['asignacion_id']);
                    if ($fila !== null) {
                        $filas[] = $fila;
                    }
                }
                if ($actor !== null && $preparados !== []) {
                    $cambios = [];
                    foreach ($preparados as $item) {
                        $a = $item['nota_anterior'] ?? null;
                        $b = $item['nota'];
                        if ($this->auditoria->diff(
                            ['nota_evaluacion' => $a],
                            ['nota_evaluacion' => $b],
                            ['nota_evaluacion' => 'Nota de evaluación']
                        ) === []) {
                            continue;
                        }
                        $cambios[] = [
                            'campo' => 'nota_evaluacion',
                            'etiqueta' => 'Nota de evaluación',
                            'anterior' => $a,
                            'nuevo' => $b,
                            'cumplimiento_id' => (int)$item['cumplimiento_id'],
                            'asignacion_id' => (int)$item['asignacion_id'],
                            'persona_id_ext' => isset($item['persona_id_ext']) ? (int)$item['persona_id_ext'] : null,
                            'numero_documento' => $item['numero_documento'] ?? null,
                        ];
                    }
                    $this->auditoria->deActor(
                        $actor,
                        'registrar_evaluaciones',
                        'cumplimientos_capacitacion',
                        $sesionId,
                        $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO, [
                            'sesion_id' => $sesionId,
                            'procesados' => count($preparados),
                            'cumplimiento_ids' => array_map(
                                static fn (array $item): int => (int)$item['cumplimiento_id'],
                                $preparados
                            ),
                        ])
                    );
                }
            });
        } catch (HttpException $e) {
            throw $e;
        } catch (PDOException $e) {
            throw new HttpException('No fue posible registrar la evaluación.', 500);
        }

        return [
            'procesados' => count($preparados),
            'items' => $this->normalizarConSoportes($filas),
        ];
    }

    public function mensajeEvaluaciones(array $resultado): string
    {
        $n = (int)$resultado['procesados'];
        if ($n === 1) {
            return '1 evaluación registrada.';
        }

        return "{$n} evaluaciones registradas.";
    }

    /**
     * @param array<string,mixed> $datos
     * @return array{asignacion_id:int,sesion_id:int,fecha_realizacion:string,resultado:string,horas_efectivas:float,observaciones:?string}
     */
    private function exigirCampos(array $datos, bool $masivo): array
    {
        $asignacionId = (int)($datos['asignacion_id'] ?? 0);
        $sesionId = (int)($datos['sesion_id'] ?? 0);
        if (!$masivo && $asignacionId < 1) {
            throw new HttpException('Debe indicar la asignación.', 422);
        }
        if ($sesionId < 1) {
            throw new HttpException('Debe indicar la sesión.', 422);
        }

        return [
            'asignacion_id' => $asignacionId,
            'sesion_id' => $sesionId,
            'fecha_realizacion' => $this->fechaRealizacion($datos['fecha_realizacion'] ?? null, null),
            'resultado' => $this->exigirResultado($datos['resultado'] ?? null),
            'horas_efectivas' => $this->exigirHoras($datos['horas_efectivas'] ?? null),
            'observaciones' => nullable_trimmed_string($datos['observaciones'] ?? null),
        ];
    }

    /**
     * @param array{asignacion_id:int,sesion_id:int,fecha_realizacion:string,resultado:string,horas_efectivas:float,observaciones:?string} $campos
     */
    private function completarUno(array $campos, ?int $usuarioId): void
    {
        $this->exigirSesion((int)$campos['sesion_id'], true);
        $this->validarParticipante((int)$campos['sesion_id'], (int)$campos['asignacion_id'], true);
        $notaEnviada = !empty($campos['nota_enviada']);
        $notaBruta = $campos['nota_evaluacion'] ?? null;
        $this->persistir(
            (int)$campos['sesion_id'],
            (int)$campos['asignacion_id'],
            $campos['fecha_realizacion'],
            $campos['resultado'],
            $campos['horas_efectivas'],
            $campos['observaciones'],
            $usuarioId,
            $notaEnviada || $notaBruta !== null ? $notaBruta : null,
            $notaEnviada || $notaBruta !== null
        );
    }

    private function persistir(
        int $sesionId,
        int $asignacionId,
        string $fecha,
        string $resultado,
        float $horas,
        ?string $observaciones,
        ?int $usuarioId,
        mixed $notaBruta = null,
        bool $escribirNota = false
    ): void {
        $existente = $this->repo->buscarPorAsignacion($asignacionId);
        $meta = $this->metaEvaluacion($existente, $sesionId);
        $nota = $this->resolverNota(
            $notaBruta,
            $escribirNota,
            $meta,
            $existente['nota_evaluacion'] ?? null
        );
        $this->exigirNotaParaAprobado($resultado, $nota, $meta);
        $this->exigirEvidenciaParaAprobado($resultado, $existente, $sesionId, $asignacionId);
        $vence = $this->vencimiento->fechaVencimientoDeAsignacion($asignacionId, $fecha);
        $campos = [
            'sesion_id' => $sesionId,
            'fecha_realizacion' => $fecha,
            'resultado' => $resultado,
            'horas_efectivas' => $horas,
            'fecha_vencimiento' => $vence,
            'observaciones' => $observaciones,
            'registrado_por_usuario_id_ext' => $usuarioId,
        ];
        if ($escribirNota || ($meta['requiere'] && $nota !== null)) {
            $campos['nota_evaluacion'] = $nota;
        }

        if ($existente === null) {
            $campos['asignacion_id'] = $asignacionId;
            $this->repo->crear($campos);
            return;
        }

        $this->repo->actualizar((int)$existente['cumplimiento_id'], $campos);
    }

    private function exigirEvidenciaParaAprobado(
        string $resultado,
        ?array $existente,
        int $sesionId,
        int $asignacionId
    ): void {
        if ($resultado !== self::RESULTADO_APROBADO) {
            return;
        }

        $capId = (int)($existente['capacitacion_id'] ?? 0);
        if ($capId < 1) {
            $part = $this->repo->participanteEnSesion($sesionId, $asignacionId);
            $capId = (int)($part['capacitacion_id'] ?? 0);
        }
        if ($capId < 1 || !$this->soportes->requiereCertificadoPorCapacitacion($capId)) {
            return;
        }

        $count = $existente !== null ? $this->soportes->contar((int)$existente['cumplimiento_id']) : 0;
        if ($count === 0) {
            throw new HttpException(SoporteService::MENSAJE_REQUIERE_CERTIFICADO, 422);
        }
    }

    private function validarParticipante(int $sesionId, int $asignacionId, bool $bloquearAprobado): void
    {
        $part = $this->repo->participanteEnSesion($sesionId, $asignacionId);
        if ($part === null) {
            throw new HttpException('El trabajador no está convocado a esta sesión.', 422);
        }

        $asistencia = strtoupper((string)($part['estado_asistencia'] ?? ''));
        if (!in_array($asistencia, self::ASISTENCIAS_VALIDAS, true)) {
            throw new HttpException(
                'Solo se puede registrar cumplimiento si el trabajador asistió.',
                422
            );
        }

        if (!$bloquearAprobado) {
            return;
        }

        $existente = $this->repo->buscarPorAsignacion($asignacionId);
        if ($existente !== null && strtoupper((string)($existente['resultado'] ?? '')) === self::RESULTADO_APROBADO) {
            throw new HttpException(self::MENSAJE_YA_REGISTRADO, 409);
        }
    }

    /**
     * @return array<string,mixed>
     */
    private function previewDe(int $sesionId, int $asignacionId, string $fecha): array
    {
        $part = $this->repo->participanteEnSesion($sesionId, $asignacionId);
        $existente = $this->repo->buscarPorAsignacion($asignacionId);
        $per = $this->vencimiento->resolverPeriodicidad($asignacionId);
        $vence = VencimientoService::calcularFechaVencimiento($fecha, $per['cantidad'], $per['unidad']);
        $asistencia = $part !== null ? strtoupper((string)$part['estado_asistencia']) : '';
        $resultadoActual = $existente !== null ? strtoupper((string)($existente['resultado'] ?? '')) : '';
        $puede = $part !== null
            && in_array($asistencia, self::ASISTENCIAS_VALIDAS, true)
            && $resultadoActual !== self::RESULTADO_APROBADO;

        $motivo = null;
        if ($part === null) {
            $motivo = 'El trabajador no está convocado a esta sesión.';
        } elseif (!in_array($asistencia, self::ASISTENCIAS_VALIDAS, true)) {
            $motivo = 'Solo se puede registrar cumplimiento si el trabajador asistió.';
        } elseif ($resultadoActual === self::RESULTADO_APROBADO) {
            $motivo = self::MENSAJE_YA_REGISTRADO;
        }

        $capId = (int)($part['capacitacion_id'] ?? $existente['capacitacion_id'] ?? 0);
        $requiereCert = $capId > 0 && $this->soportes->requiereCertificadoPorCapacitacion($capId);
        $meta = $this->metaEvaluacion($existente, $sesionId);
        $nota = $existente !== null && $existente['nota_evaluacion'] !== null
            ? (float)$existente['nota_evaluacion']
            : null;
        $cumplimientoId = $existente !== null ? (int)$existente['cumplimiento_id'] : null;
        $soportesCount = $cumplimientoId !== null ? $this->soportes->contar($cumplimientoId) : 0;

        return [
            'asignacion_id' => $asignacionId,
            'cumplimiento_id' => $cumplimientoId,
            'numero_documento' => $part['numero_documento'] ?? null,
            'persona_nombre' => $part['persona_nombre'] ?? null,
            'estado_asistencia' => $part['estado_asistencia'] ?? null,
            'resultado_actual' => $existente['resultado'] ?? null,
            'periodicidad_nombre' => $per['nombre'],
            'periodicidad_cantidad' => $per['cantidad'],
            'periodicidad_unidad' => $per['unidad'],
            'origen_periodicidad' => $per['origen'],
            'etiqueta_periodicidad' => $per['etiqueta'],
            'fecha_vencimiento' => $vence,
            'etiqueta_vencimiento' => $vence === null ? 'Sin vencimiento' : $vence,
            'puede_registrar' => $puede,
            'motivo' => $motivo,
            'requiere_certificado' => $requiereCert,
            'soportes_count' => $soportesCount,
            'requiere_evaluacion' => $meta['requiere'],
            'nota_minima' => $meta['minima'],
            'nota_evaluacion' => $nota,
            'evaluacion_aprobada' => $this->evaluacionAprobada($nota, $meta['requiere'], $meta['minima']),
        ];
    }

    /** @return array<string,mixed> */
    private function exigirSesion(int $sesionId, bool $permitirFinalizada = false): array
    {
        if ($sesionId < 1) {
            throw new HttpException('Debe indicar la sesión.', 422);
        }
        $sesion = $this->repo->sesionPorId($sesionId);
        if ($sesion === null) {
            throw new HttpException('La sesión no existe.', 404);
        }
        $estado = strtoupper((string)($sesion['estado'] ?? ''));
        if ($estado === 'EJECUTADA' && !$permitirFinalizada) {
            throw new HttpException('No es posible registrar en una capacitación finalizada.', 409);
        }
        if ($estado === 'CANCELADA') {
            throw new HttpException('No es posible registrar cumplimiento en una sesión cancelada.', 409);
        }
        if (strtoupper((string)($sesion['estado_programacion'] ?? '')) === 'CANCELADA') {
            throw new HttpException('No es posible operar sobre una programación cancelada.', 409);
        }

        return $sesion;
    }

    /**
     * @param array<string,mixed>|null $sesion
     */
    /**
     * Misma regla que Panel y Cronograma: fuera de tiempo si fecha_realizacion > fecha_limite.
     * No se usa para penalizar el % de cobertura (decisión funcional pendiente).
     */
    private function ejecutadaFueraDeTiempo(mixed $fechaRealizacion, mixed $fechaHasta): bool
    {
        if ($fechaRealizacion === null || $fechaRealizacion === '' || $fechaHasta === null || $fechaHasta === '') {
            return false;
        }
        $real = substr((string)$fechaRealizacion, 0, 10);
        $hasta = substr((string)$fechaHasta, 0, 10);
        if ($real === '' || $hasta === '') {
            return false;
        }

        return $real > $hasta;
    }

    private function fechaRealizacion(mixed $valor, ?array $sesion): string
    {
        $texto = is_string($valor) ? trim($valor) : '';
        if ($texto === '' && $sesion !== null) {
            $texto = substr((string)($sesion['fecha_hora'] ?? ''), 0, 10);
        }
        if ($texto === '') {
            throw new HttpException('La fecha de realización es obligatoria.', 422);
        }

        $dt = \DateTimeImmutable::createFromFormat('Y-m-d', $texto);
        if (!$dt instanceof \DateTimeImmutable || $dt->format('Y-m-d') !== $texto) {
            $ts = strtotime($texto);
            if (!$ts) {
                throw new HttpException('La fecha de realización no es válida.', 422);
            }
            $texto = date('Y-m-d', $ts);
        }

        return $texto;
    }

    private function exigirResultado(mixed $valor): string
    {
        $resultado = strtoupper(trim((string)$valor));
        if ($resultado === '') {
            throw new HttpException('El resultado es obligatorio.', 422);
        }
        if ($resultado !== self::RESULTADO_APROBADO) {
            throw new HttpException('El resultado debe ser APROBADO.', 422);
        }

        return $resultado;
    }

    private function exigirHoras(mixed $valor): float
    {
        if ($valor === null || $valor === '') {
            throw new HttpException('Las horas efectivas son obligatorias.', 422);
        }
        if (!is_numeric($valor)) {
            throw new HttpException('Las horas efectivas deben ser un valor numérico.', 422);
        }
        $horas = (float)$valor;
        if ($horas <= 0) {
            throw new HttpException('Las horas efectivas deben ser mayores que cero.', 422);
        }

        return round($horas, 2);
    }

    private function exigirNota(mixed $valor): float
    {
        if ($valor === null || $valor === '') {
            throw new HttpException(self::MENSAJE_NOTA_OBLIGATORIA, 422);
        }
        if (!is_numeric($valor)) {
            throw new HttpException(self::MENSAJE_NOTA_NUMERICA, 422);
        }
        $nota = round((float)$valor, 2);
        if ($nota < self::NOTA_MIN || $nota > self::NOTA_MAX) {
            throw new HttpException(self::MENSAJE_NOTA_RANGO, 422);
        }

        return $nota;
    }

    /**
     * @param array{requiere:bool,minima:float} $meta
     */
    private function resolverNota(mixed $valor, bool $enviada, array $meta, mixed $actual): ?float
    {
        if (!$meta['requiere']) {
            if ($enviada && $valor !== null && $valor !== '') {
                throw new HttpException(self::MENSAJE_NOTA_NO_REQUERIDA, 422);
            }

            return $actual !== null && $actual !== '' ? (float)$actual : null;
        }

        if ($enviada) {
            return $this->exigirNota($valor);
        }

        return $actual !== null && $actual !== '' ? round((float)$actual, 2) : null;
    }

    /**
     * @param array{requiere:bool,minima:float} $meta
     */
    private function exigirNotaParaAprobado(string $resultado, ?float $nota, array $meta): void
    {
        if ($resultado !== self::RESULTADO_APROBADO || !$meta['requiere']) {
            return;
        }
        if ($nota === null) {
            throw new HttpException(self::MENSAJE_NOTA_OBLIGATORIA, 422);
        }
        if ($nota < $meta['minima']) {
            throw new HttpException(self::MENSAJE_NOTA_MINIMA, 422);
        }
    }

    /**
     * @return array{requiere:bool,minima:float}
     */
    private function metaEvaluacion(?array $existente, int $sesionId): array
    {
        if ($existente !== null && array_key_exists('capacitacion_evaluacion', $existente)) {
            return [
                'requiere' => (int)($existente['capacitacion_evaluacion'] ?? 0) === 1,
                'minima' => round((float)($existente['capacitacion_nota_minima'] ?? 0), 2),
            ];
        }

        $sesion = $sesionId > 0 ? $this->repo->sesionPorId($sesionId) : null;

        return [
            'requiere' => (int)($sesion['capacitacion_evaluacion'] ?? 0) === 1,
            'minima' => round((float)($sesion['capacitacion_nota_minima'] ?? 0), 2),
        ];
    }

    private function evaluacionAprobada(?float $nota, bool $requiere, float $minima): ?bool
    {
        if (!$requiere || $nota === null) {
            return null;
        }

        return $nota >= $minima;
    }

    /**
     * @return array<int,mixed>
     */
    private function mapaNotas(mixed $raw): array
    {
        if (!is_array($raw)) {
            return [];
        }

        $mapa = [];
        foreach ($raw as $clave => $valor) {
            $id = (int)$clave;
            if ($id < 1) {
                continue;
            }
            $mapa[$id] = $valor;
        }

        return $mapa;
    }

    /**
     * @param mixed $raw
     * @return list<int>
     */
    private function normalizarIds(mixed $raw): array
    {
        if (is_string($raw) && $raw !== '') {
            $raw = explode(',', $raw);
        }
        if (!is_array($raw)) {
            return [];
        }

        $ids = [];
        $vistos = [];
        foreach ($raw as $valor) {
            $id = (int)$valor;
            if ($id < 1 || isset($vistos[$id])) {
                continue;
            }
            $vistos[$id] = true;
            $ids[] = $id;
        }

        return $ids;
    }

    /**
     * @param array<string,mixed> $datos
     * @return array<string,mixed>
     */
    private function ignorarCliente(array $datos): array
    {
        unset(
            $datos['usuario_id'],
            $datos['usuario_id_ext'],
            $datos['valor_anterior'],
            $datos['valor_nuevo'],
            $datos['created_at'],
            $datos['ip']
        );

        return $datos;
    }

    /**
     * @param array<string,mixed> $fila
     * @return array<string,mixed>
     */
    private function recorteAuditable(array $fila): array
    {
        $recorte = [];
        foreach (self::CAMPOS_AUDITABLES as $campo => $etiqueta) {
            $recorte[$campo] = $fila[$campo] ?? null;
        }

        return $recorte;
    }

    private function exigirFechaVencimiento(mixed $valor): string
    {
        $texto = is_string($valor) ? trim($valor) : '';
        if ($texto === '') {
            throw new HttpException('La fecha de vencimiento no es válida.', 422);
        }
        $texto = substr($texto, 0, 10);
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d', $texto);
        if (!$dt instanceof \DateTimeImmutable || $dt->format('Y-m-d') !== $texto) {
            throw new HttpException('La fecha de vencimiento no es válida.', 422);
        }

        return $texto;
    }

    /**
     * @param list<array<string,mixed>> $filas
     * @return list<array<string,mixed>>
     */
    private function normalizarConSoportes(array $filas): array
    {
        $ids = [];
        foreach ($filas as $fila) {
            if (isset($fila['cumplimiento_id'])) {
                $ids[] = (int)$fila['cumplimiento_id'];
            }
        }
        $por = $this->soportes->porCumplimientos($ids);
        $items = [];
        foreach ($filas as $fila) {
            $cid = (int)($fila['cumplimiento_id'] ?? 0);
            $fila['soportes'] = $por[$cid] ?? [];
            $items[] = $this->normalizar($fila);
        }

        return $items;
    }

    /**
     * @param array<string,mixed> $fila
     * @return array<string,mixed>
     */
    private function normalizar(array $fila): array
    {
        if ($fila === []) {
            return [];
        }

        $soportes = is_array($fila['soportes'] ?? null) ? $fila['soportes'] : [];
        $resultado = strtoupper((string)($fila['resultado'] ?? ''));
        $calculado = strtoupper((string)($fila['estado_calculado'] ?? ''));
        $vigencia = 'PENDIENTE';
        if ($resultado === self::RESULTADO_APROBADO) {
            $vigencia = in_array($calculado, ['PROXIMA_A_VENCER', 'VENCIDA', 'COMPLETADA'], true)
                ? $calculado
                : 'COMPLETADA';
        }

        return [
            'cumplimiento_id' => (int)$fila['cumplimiento_id'],
            'asignacion_id' => (int)$fila['asignacion_id'],
            'sesion_id' => $fila['sesion_id'] !== null ? (int)$fila['sesion_id'] : null,
            'persona_id_ext' => isset($fila['persona_id_ext']) ? (int)$fila['persona_id_ext'] : null,
            'persona_nombre' => $fila['persona_nombre'] ?? null,
            'numero_documento' => $fila['numero_documento'] ?? null,
            'capacitacion_id' => isset($fila['capacitacion_id']) ? (int)$fila['capacitacion_id'] : null,
            'capacitacion_codigo' => $fila['capacitacion_codigo'] ?? null,
            'capacitacion_nombre' => $fila['capacitacion_nombre'] ?? null,
            'requiere_certificado' => (int)($fila['capacitacion_certificado'] ?? 0) === 1,
            'requiere_evaluacion' => (int)($fila['capacitacion_evaluacion'] ?? 0) === 1,
            'nota_minima' => isset($fila['capacitacion_nota_minima'])
                ? round((float)$fila['capacitacion_nota_minima'], 2)
                : 0.0,
            'nota_evaluacion' => $fila['nota_evaluacion'] !== null ? (float)$fila['nota_evaluacion'] : null,
            'evaluacion_aprobada' => $this->evaluacionAprobada(
                $fila['nota_evaluacion'] !== null ? (float)$fila['nota_evaluacion'] : null,
                (int)($fila['capacitacion_evaluacion'] ?? 0) === 1,
                round((float)($fila['capacitacion_nota_minima'] ?? 0), 2)
            ),
            'fecha_realizacion' => $fila['fecha_realizacion'] ?? null,
            'resultado' => $fila['resultado'] ?? null,
            'horas_efectivas' => $fila['horas_efectivas'] !== null ? (float)$fila['horas_efectivas'] : null,
            'fecha_vencimiento' => $fila['fecha_vencimiento'] ?? null,
            'observaciones' => $fila['observaciones'] ?? null,
            'registrado_por_usuario_id_ext' => $fila['registrado_por_usuario_id_ext'] !== null
                ? (int)$fila['registrado_por_usuario_id_ext']
                : null,
            'estado_calculado' => $calculado !== '' ? $calculado : null,
            'estado_vigencia' => $vigencia,
            'soportes_count' => count($soportes),
            'soportes' => $soportes,
            'created_at' => $fila['created_at'] ?? null,
            'updated_at' => $fila['updated_at'] ?? null,
        ];
    }
}
