<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Exceptions\HttpException;
use App\Repositories\AsignacionRepository;
use App\Repositories\CapacitacionRepository;
use App\Repositories\MatrizRepository;
use Throwable;

class AsignacionService
{
    public const MENSAJE_NO_APLICABLE = 'La capacitación seleccionada no está definida como aplicable para el cargo/proyecto del trabajador. Verifique la Matriz de Aplicabilidad antes de continuar.';
    public const MENSAJE_DUPLICADO = 'El trabajador ya tiene esta capacitación asignada para el contexto correspondiente.';
    public const MENSAJE_ERROR = 'No fue posible crear la asignación.';
    public const MENSAJE_UNA = 'Capacitación asignada correctamente.';
    public const MENSAJE_VARIAS = 'Capacitaciones asignadas correctamente.';

    private AsignacionRepository $repo;
    private CapacitacionRepository $capacitaciones;
    private PersonalService $personal;
    private AuditoriaService $auditoria;
    private MatrizRepository $matriz;

    public function __construct()
    {
        $this->repo = new AsignacionRepository();
        $this->capacitaciones = new CapacitacionRepository();
        $this->personal = new PersonalService();
        $this->auditoria = new AuditoriaService();
        $this->matriz = new MatrizRepository();
    }

    public function reglas(bool $esActualizacion = false): array
    {
        if ($esActualizacion) {
            return [
                'fecha_asignacion' => 'required|date',
                'fecha_limite_cumplimiento' => 'required|date',
            ];
        }

        return [
            'persona_id_ext' => 'required|integer|min:1',
            'capacitacion_id' => 'nullable|integer|min:1',
            'capacitacion_ids' => 'nullable|array',
            'fecha_asignacion' => 'required|date',
            'fecha_limite_cumplimiento' => 'required|date',
        ];
    }

    public function reglasMasiva(): array
    {
        return [
            'persona_ids_ext' => 'required|array',
            'capacitacion_id' => 'required|integer|min:1',
            'fecha_asignacion' => 'required|date',
            'fecha_limite_cumplimiento' => 'required|date',
        ];
    }

    public function listar(
        int $pagina,
        int $porPagina,
        ?int $personaId,
        ?int $capacitacionId,
        ?string $estado,
        ?string $alerta,
        ?string $buscar,
        ?string $origen = null,
        ?int $procesoId = null,
        ?string $proyecto = null,
        ?string $fechaLimiteDesde = null,
        ?string $fechaLimiteHasta = null,
        ?int $cargoId = null
    ): array {
        $pagina = max(1, $pagina);
        $porPagina = min(100, max(1, $porPagina));
        $offset = ($pagina - 1) * $porPagina;

        if ($estado !== null && $estado !== '' && !in_array($estado, VencimientoService::ESTADOS, true)) {
            throw new HttpException('El estado calculado no es válido', 422);
        }

        if ($alerta !== null && $alerta !== '' && !in_array($alerta, ['proximas', 'vencidas'], true)) {
            throw new HttpException('El filtro de alerta debe ser proximas o vencidas', 422);
        }

        if ($origen !== null && $origen !== '' && !in_array($origen, ['AUTOMATICA', 'MANUAL', 'INDUCCION', 'REINDUCCION'], true)) {
            throw new HttpException('El origen debe ser AUTOMATICA, MANUAL, INDUCCION o REINDUCCION', 422);
        }

        // Punto de extensión: aislamiento por rol/proceso/proyecto (hoy modo global).
        $alcance = (new AlcanceDatosService())->alcanceDe([]);
        unset($alcance);

        if ($fechaLimiteDesde !== null && $fechaLimiteDesde !== '' && !$this->esFecha($fechaLimiteDesde)) {
            throw new HttpException('La fecha límite desde debe tener formato AAAA-MM-DD.', 422);
        }
        if ($fechaLimiteHasta !== null && $fechaLimiteHasta !== '' && !$this->esFecha($fechaLimiteHasta)) {
            throw new HttpException('La fecha límite hasta debe tener formato AAAA-MM-DD.', 422);
        }
        if (
            $fechaLimiteDesde !== null && $fechaLimiteDesde !== ''
            && $fechaLimiteHasta !== null && $fechaLimiteHasta !== ''
            && $fechaLimiteDesde > $fechaLimiteHasta
        ) {
            throw new HttpException('La fecha límite desde no puede ser posterior a la fecha hasta.', 422);
        }

        $filas = $this->repo->listar(
            $porPagina,
            $offset,
            $personaId,
            $capacitacionId,
            $estado,
            $alerta,
            $buscar,
            $origen,
            $procesoId,
            $proyecto,
            $fechaLimiteDesde,
            $fechaLimiteHasta,
            $cargoId
        );

        return [
            'items' => array_map([$this, 'normalizar'], $filas),
            'total' => $this->repo->contar(
                $personaId,
                $capacitacionId,
                $estado,
                $alerta,
                $buscar,
                $origen,
                $procesoId,
                $proyecto,
                $fechaLimiteDesde,
                $fechaLimiteHasta,
                $cargoId
            ),
            'page' => $pagina,
            'per_page' => $porPagina,
        ];
    }

    /** @return array{total:int,items:list<array<string,mixed>>} */
    public function proximas(): array
    {
        $items = array_map([$this, 'normalizar'], $this->repo->proximasPendientes());

        return [
            'total' => count($items),
            'items' => $items,
        ];
    }

    public function ver(int $id): array
    {
        $fila = $this->repo->buscarPorId($id);

        if ($fila === null) {
            throw new HttpException('Asignación no encontrada', 404);
        }

        return $this->normalizar($fila);
    }

    /**
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function crear(array $datos, int $usuarioId, ?array $actor = null): array
    {
        try {
            $personaId = (int)$datos['persona_id_ext'];
            $capacitacionId = (int)($datos['capacitacion_id'] ?? 0);
            if ($capacitacionId < 1) {
                $ids = $this->normalizarCapacitacionIds($datos['capacitacion_ids'] ?? null);
                if (count($ids) !== 1) {
                    throw new HttpException('Debe indicar la capacitación.', 422);
                }
                $capacitacionId = $ids[0];
            }

            $persona = $this->personal->ver($personaId);
            $this->exigirPersonaActiva($persona);
            $this->exigirCapacitacionActiva($capacitacionId);
            $this->exigirAplicable($persona, $capacitacionId);

            if ($this->repo->pendienteDuplicada($personaId, $capacitacionId)) {
                throw new HttpException(self::MENSAJE_DUPLICADO, 409);
            }

            $fechaAsignacion = $this->fechaONulo($datos['fecha_asignacion'] ?? null);
            $fechaLimite = $this->fechaONulo($datos['fecha_limite_cumplimiento'] ?? null);
            $this->exigirPeriodoAsignacion($fechaAsignacion, $fechaLimite);

            return $this->persistirManual(
                $persona,
                $capacitacionId,
                $fechaAsignacion,
                $fechaLimite,
                $usuarioId,
                $actor
            );
        } catch (HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            throw new HttpException(self::MENSAJE_ERROR, 500);
        }
    }

    /**
     * Varias capacitaciones a un trabajador. Las no aplicables o duplicadas se omiten.
     *
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array{seleccionados:int, creadas:int, omitidas:int, items:list<array<string,mixed>>, omitidas_detalle:list<array<string,mixed>>}
     */
    public function crearVarias(array $datos, int $usuarioId, ?array $actor = null): array
    {
        $personaId = (int)$datos['persona_id_ext'];
        $capIds = $this->normalizarCapacitacionIds($datos['capacitacion_ids'] ?? $datos['capacitacion_id'] ?? null);
        $persona = $this->personal->ver($personaId);
        $this->exigirPersonaActiva($persona);

        $fechaAsignacion = $this->fechaONulo($datos['fecha_asignacion'] ?? null);
        $fechaLimite = $this->fechaONulo($datos['fecha_limite_cumplimiento'] ?? null);
        $this->exigirPeriodoAsignacion($fechaAsignacion, $fechaLimite);

        $items = [];
        $omitidasDetalle = [];

        foreach ($capIds as $capacitacionId) {
            try {
                $this->exigirCapacitacionActiva($capacitacionId);
                $this->exigirAplicable($persona, $capacitacionId);
                if ($this->repo->pendienteDuplicada($personaId, $capacitacionId)) {
                    $omitidasDetalle[] = [
                        'capacitacion_id' => $capacitacionId,
                        'motivo' => 'duplicado',
                        'mensaje' => self::MENSAJE_DUPLICADO,
                    ];
                    continue;
                }
                $items[] = $this->persistirManual(
                    $persona,
                    $capacitacionId,
                    $fechaAsignacion,
                    $fechaLimite,
                    $usuarioId,
                    $actor
                );
            } catch (HttpException $e) {
                if ($e->getMessage() === self::MENSAJE_NO_APLICABLE) {
                    $omitidasDetalle[] = [
                        'capacitacion_id' => $capacitacionId,
                        'motivo' => 'no_aplicable',
                        'mensaje' => self::MENSAJE_NO_APLICABLE,
                    ];
                    continue;
                }
                throw $e;
            }
        }

        if ($items === [] && $omitidasDetalle !== []) {
            $soloNoAplicable = count($omitidasDetalle) === 1
                && ($omitidasDetalle[0]['motivo'] ?? '') === 'no_aplicable';
            if ($soloNoAplicable) {
                throw new HttpException(self::MENSAJE_NO_APLICABLE, 422);
            }
        }

        return [
            'seleccionados' => count($capIds),
            'creadas' => count($items),
            'omitidas' => count($omitidasDetalle),
            'items' => $items,
            'omitidas_detalle' => $omitidasDetalle,
        ];
    }

    public function mensajeVarias(array $resultado): string
    {
        $creadas = (int)$resultado['creadas'];
        if ($creadas > 1) {
            return self::MENSAJE_VARIAS;
        }
        if ($creadas === 1) {
            return self::MENSAJE_UNA;
        }

        return 'No se crearon asignaciones.';
    }

    /**
     * @param array<string,mixed> $persona
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    private function persistirManual(
        array $persona,
        int $capacitacionId,
        string $fechaAsignacion,
        string $fechaLimite,
        int $usuarioId,
        ?array $actor
    ): array {
        $personaId = (int)$persona['persona_id'];

        return $this->repo->transaccion(function () use (
            $personaId,
            $persona,
            $capacitacionId,
            $fechaAsignacion,
            $fechaLimite,
            $usuarioId,
            $actor
        ): array {
            $id = $this->repo->crear([
                'persona_id_ext' => $personaId,
                'contrato_id_ext' => $persona['contrato_id'],
                'capacitacion_id' => $capacitacionId,
                'matriz_aplicabilidad_id' => null,
                'fecha_asignacion' => $fechaAsignacion,
                'fecha_limite_cumplimiento' => $fechaLimite,
                'origen' => 'MANUAL',
                'cargo_id_ext' => $persona['cargo_id'],
                'area_id' => null,
                'proceso_id' => $this->procesoIdDePersona($persona),
                'ambito' => null,
                'proyecto' => $persona['proyecto'],
                'creada_por_usuario_id_ext' => $usuarioId,
            ]);
            $creado = $this->ver($id);
            if ($actor !== null) {
                $this->auditoria->deActor($actor, 'crear', 'asignaciones_capacitacion', $id, [
                    'origen' => 'MANUAL',
                    'persona_id_ext' => $personaId,
                    'capacitacion_id' => $capacitacionId,
                    'asignacion' => $creado,
                ]);
            }

            return $creado;
        });
    }

    /**
     * Asignación MANUAL a varios trabajadores. No toca la matriz.
     *
     * @param array<string,mixed> $datos
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     * @return array{seleccionados:int, creadas:int, omitidas:int, errores:int, items:list<array<string,mixed>>, omitidas_detalle:list<array<string,mixed>>}
     */
    public function crearMasivo(array $datos, int $usuarioId, ?array $actor = null): array
    {
        $ids = $this->normalizarPersonaIds($datos['persona_ids_ext'] ?? []);
        $capacitacionId = (int)$datos['capacitacion_id'];
        $cap = $this->capacitaciones->buscarPorId($capacitacionId);

        if ($cap === null) {
            throw new HttpException('La capacitación no existe', 422);
        }

        if (($cap['estado'] ?? '') !== 'ACTIVA') {
            throw new HttpException('Solo se puede asignar una capacitación activa.', 422);
        }

        $fechaAsignacion = $this->fechaONulo($datos['fecha_asignacion'] ?? null);
        $fechaLimite = $this->fechaONulo($datos['fecha_limite_cumplimiento'] ?? null);
        $this->exigirPeriodoAsignacion($fechaAsignacion, $fechaLimite);

        $personas = [];
        $errores = 0;
        $omitidasDetalle = [];

        foreach ($ids as $personaId) {
            try {
                $personas[] = $this->personal->ver($personaId);
            } catch (HttpException $e) {
                if ($e->getStatusCode() !== 404) {
                    throw $e;
                }
                $errores++;
                $omitidasDetalle[] = [
                    'persona_id_ext' => $personaId,
                    'motivo' => 'inexistente',
                    'mensaje' => 'El trabajador no existe.',
                ];
            }
        }

        if ($personas === []) {
            throw new HttpException('Ninguno de los trabajadores seleccionados existe.', 422);
        }

        $creadasIds = [];
        $omitidas = 0;

        $this->repo->transaccion(function () use (
            $personas,
            $capacitacionId,
            $fechaLimite,
            $fechaAsignacion,
            $usuarioId,
            $actor,
            $ids,
            $errores,
            $cap,
            &$creadasIds,
            &$omitidas,
            &$omitidasDetalle
        ): int {
            foreach ($personas as $persona) {
                $personaId = (int)$persona['persona_id'];
                $etiquetaPersona = [
                    'persona_nombre' => $persona['nombre_completo'] ?? null,
                    'numero_documento' => $persona['numero_documento'] ?? null,
                ];
                if (($persona['estado'] ?? '') !== 'Activo') {
                    $omitidas++;
                    $omitidasDetalle[] = array_merge([
                        'persona_id_ext' => $personaId,
                        'motivo' => 'inactivo',
                        'mensaje' => 'No es posible asignar a un trabajador inactivo.',
                    ], $etiquetaPersona);
                    continue;
                }
                if (!$this->esAplicable($persona, $capacitacionId)) {
                    $omitidas++;
                    $omitidasDetalle[] = array_merge([
                        'persona_id_ext' => $personaId,
                        'motivo' => 'no_aplicable',
                        'mensaje' => self::MENSAJE_NO_APLICABLE,
                    ], $etiquetaPersona);
                    continue;
                }
                if ($this->repo->pendienteDuplicada($personaId, $capacitacionId)) {
                    $omitidas++;
                    $omitidasDetalle[] = array_merge([
                        'persona_id_ext' => $personaId,
                        'motivo' => 'duplicado',
                        'mensaje' => self::MENSAJE_DUPLICADO,
                    ], $etiquetaPersona);
                    continue;
                }

                $creadasIds[] = $this->repo->crear([
                    'persona_id_ext' => $personaId,
                    'contrato_id_ext' => $persona['contrato_id'],
                    'capacitacion_id' => $capacitacionId,
                    'matriz_aplicabilidad_id' => null,
                    'fecha_asignacion' => $fechaAsignacion,
                    'fecha_limite_cumplimiento' => $fechaLimite,
                    'origen' => 'MANUAL',
                    'cargo_id_ext' => $persona['cargo_id'],
                    'area_id' => null,
                    'proceso_id' => $this->procesoIdDePersona($persona),
                    'ambito' => null,
                    'proyecto' => $persona['proyecto'],
                    'creada_por_usuario_id_ext' => $usuarioId,
                ]);
            }

            if ($actor !== null && $creadasIds !== []) {
                $this->auditoria->deActor(
                    $actor,
                    'asignar_masivo',
                    'asignaciones_capacitacion',
                    (int)$creadasIds[0],
                    [
                        'tipo' => 'MASIVA',
                        'origen' => 'MANUAL',
                        'capacitacion_id' => $capacitacionId,
                        'capacitacion_codigo' => $cap['codigo'] ?? null,
                        'capacitacion_nombre' => $cap['nombre'] ?? null,
                        'seleccionados' => count($ids),
                        'creadas' => count($creadasIds),
                        'omitidas' => $omitidas,
                        'errores' => $errores,
                        'trabajadores' => count($creadasIds),
                        'asignacion_ids' => $creadasIds,
                        'omitidas_detalle' => $omitidasDetalle,
                    ]
                );
            }

            return count($creadasIds);
        });

        $items = [];
        foreach ($creadasIds as $id) {
            $items[] = $this->ver($id);
        }

        return [
            'seleccionados' => count($ids),
            'creadas' => count($items),
            'omitidas' => $omitidas,
            'errores' => $errores,
            'items' => $items,
            'omitidas_detalle' => $omitidasDetalle,
        ];
    }

    public function mensajeMasivo(array $resultado): string
    {
        $creadas = (int)$resultado['creadas'];
        $omitidas = (int)$resultado['omitidas'];
        $porMotivo = ['duplicado' => 0, 'no_aplicable' => 0, 'inactivo' => 0];
        foreach ($resultado['omitidas_detalle'] ?? [] as $fila) {
            $motivo = (string)($fila['motivo'] ?? '');
            if (isset($porMotivo[$motivo])) {
                $porMotivo[$motivo]++;
            }
        }

        $partes = [];
        if ($creadas > 0) {
            $partes[] = $creadas === 1
                ? '1 trabajador fue asignado correctamente.'
                : "{$creadas} trabajadores fueron asignados correctamente.";
        }
        if ($porMotivo['duplicado'] > 0) {
            $partes[] = $porMotivo['duplicado'] === 1
                ? '1 omitido por duplicidad.'
                : "{$porMotivo['duplicado']} omitidos por duplicidad.";
        }
        if ($porMotivo['no_aplicable'] > 0) {
            $partes[] = $porMotivo['no_aplicable'] === 1
                ? '1 no aplicable según matriz.'
                : "{$porMotivo['no_aplicable']} no aplicables según matriz.";
        }
        if ($porMotivo['inactivo'] > 0) {
            $partes[] = $porMotivo['inactivo'] === 1
                ? '1 trabajador inactivo omitido.'
                : "{$porMotivo['inactivo']} trabajadores inactivos omitidos.";
        }

        if ($partes !== []) {
            return implode(' ', $partes);
        }

        if ($omitidas > 0) {
            return "Ningún trabajador nuevo fue asignado. {$omitidas} fueron omitidos.";
        }

        return 'No se crearon asignaciones.';
    }

    /**
     * @return list<int>
     */
    private function normalizarPersonaIds(mixed $bruto): array
    {
        if (!is_array($bruto) || $bruto === []) {
            throw new HttpException('Debe seleccionar al menos un trabajador.', 422);
        }

        $ids = [];
        foreach ($bruto as $valor) {
            $id = (int)$valor;
            if ($id <= 0) {
                throw new HttpException('El identificador de trabajador no es válido.', 422);
            }
            $ids[$id] = $id;
        }

        return array_values($ids);
    }

    /**
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function actualizar(int $id, array $datos, ?array $actor = null): array
    {
        $antes = $this->ver($id);
        if (!empty($antes['tiene_cumplimiento'])) {
            throw new HttpException(
                'No es posible modificar el período porque la asignación ya tiene ejecución registrada.',
                409
            );
        }
        if ($this->repo->tieneParticipacionSesion($id)) {
            throw new HttpException(
                'No es posible modificar el período porque la asignación está vinculada a una sesión.',
                409
            );
        }

        $fechaAsignacion = $this->fechaONulo($datos['fecha_asignacion'] ?? null);
        $fechaLimite = $this->fechaONulo($datos['fecha_limite_cumplimiento'] ?? null);
        $this->exigirPeriodoAsignacion($fechaAsignacion, $fechaLimite);

        return $this->repo->transaccion(function () use ($id, $fechaAsignacion, $fechaLimite, $antes, $actor): array {
            $this->repo->actualizar($id, [
                'fecha_asignacion' => $fechaAsignacion,
                'fecha_limite_cumplimiento' => $fechaLimite,
            ]);
            $despues = $this->ver($id);
            if ($actor !== null) {
                $campos = [
                    'fecha_asignacion' => 'Fecha desde',
                    'fecha_limite_cumplimiento' => 'Fecha hasta',
                ];
                $cambios = $this->auditoria->diff($antes, $despues, $campos);
                if ($cambios !== []) {
                    $this->auditoria->deActor(
                        $actor,
                        'actualizar',
                        'asignaciones_capacitacion',
                        $id,
                        $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO),
                        [
                            'fecha_asignacion' => $antes['fecha_asignacion'] ?? null,
                            'fecha_limite_cumplimiento' => $antes['fecha_limite_cumplimiento'] ?? null,
                        ]
                    );
                }
            }

            return $despues;
        });
    }

    /**
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function eliminar(int $id, ?array $actor = null): string
    {
        $antes = $this->ver($id);

        if ($this->repo->tieneCumplimiento($id)) {
            throw new HttpException(
                'No se puede eliminar porque ya tiene un cumplimiento registrado',
                409
            );
        }
        if ($this->repo->tieneParticipacionSesion($id)) {
            throw new HttpException(
                'No se puede eliminar porque la asignación está vinculada a una sesión.',
                409
            );
        }
        if ($this->repo->tienePlanDetalle($id)) {
            throw new HttpException(
                'No se puede eliminar porque la asignación está vinculada al plan anual.',
                409
            );
        }

        return $this->repo->transaccion(function () use ($id, $antes, $actor): string {
            $this->repo->eliminar($id);
            if ($actor !== null) {
                $this->auditoria->deActor(
                    $actor,
                    'eliminar',
                    'asignaciones_capacitacion',
                    $id,
                    ['mensaje' => 'Asignación eliminada'],
                    $antes
                );
            }

            return 'Asignación eliminada';
        });
    }

    /** @param array<string,mixed> $fila */
    private function normalizar(array $fila): array
    {
        $dias = $fila['dias_restantes'] !== null ? (int)$fila['dias_restantes'] : null;

        return [
            'asignacion_id' => (int)$fila['asignacion_id'],
            'persona_id_ext' => (int)$fila['persona_id_ext'],
            'persona_nombre' => $fila['persona_nombre'] !== null && $fila['persona_nombre'] !== ''
                ? (string)$fila['persona_nombre']
                : null,
            'numero_documento' => $fila['numero_documento'] !== null && $fila['numero_documento'] !== ''
                ? (string)$fila['numero_documento']
                : null,
            'contrato_id_ext' => $fila['contrato_id_ext'] !== null ? (int)$fila['contrato_id_ext'] : null,
            'capacitacion_id' => (int)$fila['capacitacion_id'],
            'capacitacion_codigo' => (string)$fila['capacitacion_codigo'],
            'capacitacion_nombre' => (string)$fila['capacitacion_nombre'],
            'fecha_asignacion' => $fila['fecha_asignacion'] !== null
                ? substr((string)$fila['fecha_asignacion'], 0, 10)
                : null,
            'fecha_limite_cumplimiento' => $fila['fecha_limite_cumplimiento'] !== null
                ? substr((string)$fila['fecha_limite_cumplimiento'], 0, 10)
                : null,
            'fecha_desde' => $fila['fecha_asignacion'] !== null
                ? substr((string)$fila['fecha_asignacion'], 0, 10)
                : null,
            'fecha_hasta' => $fila['fecha_limite_cumplimiento'] !== null
                ? substr((string)$fila['fecha_limite_cumplimiento'], 0, 10)
                : null,
            'origen' => (string)$fila['origen'],
            'periodicidad_nombre' => isset($fila['periodicidad_nombre']) && $fila['periodicidad_nombre'] !== ''
                ? humanizar_nombre_unidad((string)$fila['periodicidad_nombre'])
                : null,
            'obligatoria' => array_key_exists('obligatoria', $fila) && $fila['obligatoria'] !== null
                ? ((int)$fila['obligatoria'] === 1)
                : null,
            'cargo_id_ext' => $fila['cargo_id_ext'] !== null ? (int)$fila['cargo_id_ext'] : null,
            'cargo' => isset($fila['cargo']) && $fila['cargo'] !== '' ? (string)$fila['cargo'] : null,
            'ambito' => $fila['ambito'],
            'proyecto' => $fila['proyecto'],
            'estado_calculado' => (string)$fila['estado_calculado'],
            'tiene_cumplimiento' => $fila['cumplimiento_id'] !== null,
            'cumplimiento_id' => $fila['cumplimiento_id'] !== null ? (int)$fila['cumplimiento_id'] : null,
            'cumplimiento_sesion_id' => isset($fila['cumplimiento_sesion_id']) && $fila['cumplimiento_sesion_id'] !== null
                ? (int)$fila['cumplimiento_sesion_id']
                : null,
            'cumplimiento_resultado' => $fila['cumplimiento_resultado'] ?? null,
            'fecha_realizacion' => $fila['fecha_realizacion'] ?? null,
            'horas_efectivas' => isset($fila['horas_efectivas']) && $fila['horas_efectivas'] !== null
                ? (float)$fila['horas_efectivas']
                : null,
            'fecha_vencimiento' => $fila['fecha_vencimiento'] ?? null,
            'dias_restantes' => $dias,
            'etiqueta_dias' => VencimientoService::etiquetaDias($dias),
        ];
    }

    /**
     * @param array<string,mixed> $persona
     */
    private function procesoIdDePersona(array $persona): ?int
    {
        $lista = $persona['procesos'] ?? [];
        if (is_array($lista) && $lista !== []) {
            $id = (int)($lista[0]['proceso_id'] ?? 0);
            if ($id > 0) {
                return $id;
            }
        }

        $cargoId = (int)($persona['cargo_id'] ?? 0);
        $proyecto = is_string($persona['proyecto'] ?? null) ? trim((string)$persona['proyecto']) : '';

        return $this->matriz->procesoIdParaCargo($cargoId, $proyecto !== '' ? $proyecto : null);
    }

    private function exigirPersonaActiva(array $persona): void
    {
        if (($persona['estado'] ?? '') !== 'Activo') {
            throw new HttpException('No es posible asignar a un trabajador inactivo.', 422);
        }
    }

    private function exigirCapacitacionActiva(int $capacitacionId): void
    {
        $cap = $this->capacitaciones->buscarPorId($capacitacionId);
        if ($cap === null) {
            throw new HttpException('La capacitación no existe', 422);
        }
        if (($cap['estado'] ?? '') !== 'ACTIVA') {
            throw new HttpException('Solo se puede asignar una capacitación activa.', 422);
        }
    }

    /**
     * @param array<string,mixed> $persona
     */
    private function exigirAplicable(array $persona, int $capacitacionId): void
    {
        if (!$this->esAplicable($persona, $capacitacionId)) {
            throw new HttpException(self::MENSAJE_NO_APLICABLE, 422);
        }
    }

    /**
     * @param array<string,mixed> $persona
     */
    private function esAplicable(array $persona, int $capacitacionId): bool
    {
        $cargoId = isset($persona['cargo_id']) ? (int)$persona['cargo_id'] : 0;
        $proyecto = is_string($persona['proyecto'] ?? null) ? (string)$persona['proyecto'] : null;
        $filas = $this->matriz->aplicables($cargoId > 0 ? $cargoId : null, null, $proyecto);
        foreach ($filas as $fila) {
            if ((int)($fila['capacitacion_id'] ?? 0) === $capacitacionId) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<int>
     */
    private function normalizarCapacitacionIds(mixed $bruto): array
    {
        if ($bruto === null || $bruto === '') {
            return [];
        }
        if (!is_array($bruto)) {
            $id = (int)$bruto;
            return $id > 0 ? [$id] : [];
        }

        $ids = [];
        foreach ($bruto as $valor) {
            $id = (int)$valor;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }

    private function exigirPeriodoAsignacion(?string $fechaDesde, ?string $fechaHasta): void
    {
        if ($fechaDesde === null || $fechaDesde === '') {
            throw new HttpException('La fecha desde es obligatoria.', 422);
        }
        if ($fechaHasta === null || $fechaHasta === '') {
            throw new HttpException('La fecha hasta es obligatoria.', 422);
        }
        if ($fechaHasta < $fechaDesde) {
            throw new HttpException('La fecha hasta no puede ser anterior a la fecha desde.', 422);
        }
    }

    private function fechaONulo(mixed $valor): ?string
    {
        if ($valor === null || $valor === '') {
            return null;
        }

        $texto = (string)$valor;
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d', $texto);

        if ($dt instanceof \DateTimeImmutable && $dt->format('Y-m-d') === $texto) {
            return $texto;
        }

        $ts = strtotime($texto);

        return $ts ? date('Y-m-d', $ts) : null;
    }

    private function esFecha(string $valor): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor)) {
            return false;
        }
        $partes = explode('-', $valor);

        return checkdate((int)$partes[1], (int)$partes[2], (int)$partes[0]);
    }
}
