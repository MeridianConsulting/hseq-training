<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Exceptions\HttpException;
use App\Core\Logger;
use App\Repositories\AlertaRepository;
use App\Repositories\HistorialContextoRepository;
use App\Repositories\MatrizRepository;
use App\Repositories\PersonaContextoRepository;
use App\Repositories\PersonalRepository;
use PDOException;
use Throwable;

class PersonalService
{
    public const TIPO_DOCUMENTO_CC = 1;
    public const FECHA_NACIMIENTO_TECNICA = '01011900';
    public const MAX_DOCUMENTO = 15;
    public const MENSAJE_404 = 'El trabajador no existe en la base corporativa.';
    public const MENSAJE_LISTAR = 'Error al obtener la información del sistema corporativo.';
    public const MENSAJE_VER = 'No fue posible consultar la información del trabajador.';

    private PersonalRepository $repo;
    private HistorialContextoRepository $historial;
    private PersonaContextoRepository $contexto;
    private AuditoriaService $auditoria;
    private ?MotorAsignacionService $motor = null;
    private ?MatrizRepository $matriz = null;
    private ?AlertaRepository $alertasRepo = null;

    public function __construct()
    {
        $this->repo = new PersonalRepository();
        $this->historial = new HistorialContextoRepository();
        $this->contexto = new PersonaContextoRepository();
        $this->auditoria = new AuditoriaService();
    }

    private function motorAsignacion(): MotorAsignacionService
    {
        return $this->motor ??= new MotorAsignacionService();
    }

    public function listar(
        int $pagina,
        int $porPagina,
        ?string $buscar,
        ?string $estado,
        ?int $cargoId,
        ?string $proyecto = null,
        ?int $procesoId = null
    ): array {
        $pagina = max(1, $pagina);
        $porPagina = min(100, max(1, $porPagina));
        $offset = ($pagina - 1) * $porPagina;

        if ($estado !== null && $estado !== '' && !in_array($estado, ['Activo', 'Inactivo'], true)) {
            throw new HttpException('El estado laboral debe ser Activo o Inactivo.', 422);
        }

        try {
            $proyectoFiltro = $this->proyectoListado($procesoId, $proyecto);
            $cargoIds = null;
            $personaIds = null;
            if ($procesoId !== null && $procesoId > 0) {
                $cargoIds = $this->matriz()->cargoIdsActivosPorProceso($procesoId);
                $personaIds = $proyectoFiltro !== null
                    ? $this->contexto->personaIdsPorProcesoYProyecto($procesoId, $proyectoFiltro)
                    : $this->contexto->personaIdsPorProceso($procesoId);
            }

            $items = $this->adjuntarProcesos(array_map(
                [$this, 'normalizar'],
                $this->repo->listar(
                    $porPagina,
                    $offset,
                    $buscar,
                    $estado,
                    $cargoId,
                    $proyectoFiltro,
                    $cargoIds,
                    $personaIds
                )
            ));

            return [
                'items' => $items,
                'total' => $this->repo->contar(
                    $buscar,
                    $estado,
                    $cargoId,
                    $proyectoFiltro,
                    $cargoIds,
                    $personaIds
                ),
                'page' => $pagina,
                'per_page' => $porPagina,
            ];
        } catch (Throwable $e) {
            $this->falloPersonal($e, self::MENSAJE_LISTAR);
        }
    }

    /**
     * @return list<array<string,mixed>>
     */
    public function listarActivosParaMotor(): array
    {
        try {
            return $this->repo->listarActivosParaMotor();
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    public function ver(int $personaId): array
    {
        try {
            $fila = $this->repo->buscarPorId($personaId);
        } catch (Throwable $e) {
            $this->falloPersonal($e, self::MENSAJE_VER);
        }

        if ($fila === null) {
            throw new HttpException(self::MENSAJE_404, 404);
        }

        $items = $this->adjuntarProcesos([$this->normalizar($fila)]);

        return $items[0];
    }

    /**
     * @return array{procesos:list<array{proceso_id:int,nombre:string}>,proyectos:list<string>,cargos:list<array{cargo_id:int,nombre_cargo:string}>}
     */
    public function opciones(): array
    {
        try {
            return [
                'procesos' => $this->alertasRepo()->procesosActivos(),
                'proyectos' => $this->alertasRepo()->proyectos(),
                'cargos' => $this->cargos(),
            ];
        } catch (Throwable $e) {
            $this->falloPersonal($e, self::MENSAJE_LISTAR);
        }
    }

    /**
     * Hoja de vida: ficha corporativa + capacitación (sin duplicar lógica de otros módulos).
     *
     * @return array<string,mixed>
     */
    public function perfil(int $personaId): array
    {
        $ficha = $this->ver($personaId);

        try {
            $aplicables = [];
            $cargoId = $ficha['cargo_id'] !== null ? (int)$ficha['cargo_id'] : 0;
            $proyecto = is_string($ficha['proyecto'] ?? null) ? trim((string)$ficha['proyecto']) : '';
            $proyectoFiltro = $proyecto !== '' ? $proyecto : null;
            $procesoIds = [];
            foreach ($ficha['procesos'] ?? [] as $proc) {
                if (!is_array($proc)) {
                    continue;
                }
                $pid = (int)($proc['proceso_id'] ?? 0);
                if ($pid > 0) {
                    $procesoIds[$pid] = $pid;
                }
            }
            if ($procesoIds === [] && $cargoId > 0) {
                $desdeMatriz = $this->matriz()->procesoIdParaCargo($cargoId, $proyectoFiltro);
                if ($desdeMatriz !== null && $desdeMatriz > 0) {
                    $procesoIds[$desdeMatriz] = $desdeMatriz;
                }
            }

            $vistos = [];
            if ($cargoId > 0) {
                $consultas = $procesoIds !== [] ? array_values($procesoIds) : [null];
                foreach ($consultas as $procesoId) {
                    foreach ($this->matriz()->aplicables($cargoId, $procesoId, $proyectoFiltro) as $fila) {
                        if ($procesoId === null) {
                            $procesoFila = $fila['proceso_id'] ?? null;
                            if ($procesoFila !== null && (int)$procesoFila > 0) {
                                continue;
                            }
                        }
                        $cid = (int)($fila['capacitacion_id'] ?? 0);
                        if ($cid < 1 || isset($vistos[$cid])) {
                            continue;
                        }
                        $vistos[$cid] = true;
                        $aplicables[] = $this->normalizarAplicable($fila);
                    }
                }
            }

            $asignaciones = (new AsignacionService())->listar(1, 100, $personaId, null, null, null, null);
            $pendientes = [];
            $ejecutadas = [];
            foreach ($asignaciones['items'] as $asig) {
                $estado = (string)($asig['estado_calculado'] ?? '');
                $resultado = $asig['cumplimiento_resultado'] ?? null;
                if ($estado === 'COMPLETADA' || $resultado === 'APROBADO') {
                    $ejecutadas[] = $asig;
                } else {
                    $pendientes[] = $asig;
                }
            }

            $cumplimientos = (new CumplimientoService())->listar(1, 100, ['persona_id' => $personaId]);
            $evaluaciones = [];
            $soportes = [];
            foreach ($cumplimientos['items'] as $cump) {
                if (($cump['nota_evaluacion'] ?? null) !== null) {
                    $evaluaciones[] = $cump;
                }
                foreach ($cump['soportes'] ?? [] as $soporte) {
                    $soportes[] = $soporte;
                }
            }

            $historial = (new SesionService())->historialPersona($personaId);
            $alertas = (new AlertaService())->listarTodos(['persona_id' => $personaId]);

            return [
                'ficha' => $ficha,
                'aplicables' => $aplicables,
                'pendientes' => $pendientes,
                'ejecutadas' => $ejecutadas,
                'cumplimientos' => $cumplimientos['items'],
                'evaluaciones' => $evaluaciones,
                'soportes' => $soportes,
                'historial_sesiones' => $historial,
                'alertas' => $alertas['items'],
            ];
        } catch (HttpException $e) {
            throw $e;
        } catch (Throwable $e) {
            $this->falloPersonal($e, self::MENSAJE_VER);
        }
    }

    public function cargos(): array
    {
        try {
            return $this->mapearCargos($this->repo->cargos());
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    /**
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    /**
     * @param list<string> $proyectosObra
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    public function cargosDeContexto(?string $proyecto, array $proyectosObra = []): array
    {
        try {
            return $this->mapearCargos($this->repo->cargosDeContexto($proyecto, $proyectosObra));
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    /**
     * @param list<array<string,mixed>> $filas
     * @return list<array{cargo_id:int,nombre_cargo:string}>
     */
    private function mapearCargos(array $filas): array
    {
        return array_map(static function (array $fila): array {
            return [
                'cargo_id' => (int)$fila['cargo_id'],
                'nombre_cargo' => (string)$fila['nombre_cargo'],
            ];
        }, $filas);
    }

    public function tiposDocumento(): array
    {
        try {
            return array_map(static function (array $fila): array {
                return [
                    'tipo_documento_id' => (int)$fila['tipo_documento_id'],
                    'descripcion' => (string)$fila['descripcion'],
                    'abreviatura' => (string)$fila['abreviatura'],
                ];
            }, $this->repo->tiposDocumento());
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    public function cargoExiste(int $cargoId): bool
    {
        try {
            return $this->repo->cargoExiste($cargoId);
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    /** @return array<int,string> */
    public function nombresCargosPorIds(array $ids): array
    {
        try {
            return $this->repo->nombresCargosPorIds($ids);
        } catch (Throwable $e) {
            return [];
        }
    }

    /**
     * @param array<string, mixed> $entrada
     */
    public function crear(array $entrada, bool $sincronizarMotor = true): array
    {
        $preparado = $this->prepararEntrada($entrada, null);

        if (!$preparado['ok']) {
            throw new HttpException((string)$preparado['motivo'], $this->codigoHttp((string)$preparado['motivo']));
        }

        $personaId = $this->persistirAlta($preparado['datos']);
        $persona = $this->ver($personaId);
        $persona['sincronizacion'] = $sincronizarMotor
            ? $this->sincronizarAsignaciones($persona)
            : ['creadas' => 0, 'omitidas' => 0, 'creadas_especiales' => [], 'error' => null];

        return $persona;
    }

    /**
     * @param array<string, mixed> $entrada
     * @param array{usuario_id:?int,nombre:?string,ip:?string}|null $actor
     */
    public function editar(int $personaId, array $entrada, ?array $actor = null): array
    {
        $actual = $this->ver($personaId);

        $correo = $this->normalizarTexto($entrada['correo'] ?? $entrada['correo_corporativo'] ?? '');
        if ($correo !== '' && filter_var($correo, FILTER_VALIDATE_EMAIL) === false) {
            throw new HttpException('El correo no tiene un formato válido.', 422);
        }

        $cargoId = $this->resolverCargoId($entrada, null);
        if ($cargoId === null) {
            $cargoBruto = $this->normalizarTexto($entrada['cargo'] ?? $entrada['cargo_id'] ?? '');
            throw new HttpException(
                $cargoBruto === '' ? 'El cargo es obligatorio.' : 'El cargo no existe en el catálogo.',
                422
            );
        }

        $contexto = $this->resolverContextoHseq($entrada);
        $proyecto = $contexto['proyecto'];

        try {
            $this->repo->transaccion(function () use ($personaId, $actual, $correo, $cargoId, $proyecto, $contexto): int {
                $this->repo->actualizarPersona($personaId, [
                    'correo_corporativo' => $correo !== '' ? $correo : null,
                    'cargo_id' => $cargoId,
                ]);

                $contratoId = $actual['contrato_id'];
                if ($contratoId) {
                    $this->repo->actualizarContrato($contratoId, [
                        'proyecto' => $proyecto,
                    ]);
                } else {
                    $fechaInicio = is_string($actual['contrato_fecha_inicio'] ?? null)
                        && $actual['contrato_fecha_inicio'] !== ''
                        ? $actual['contrato_fecha_inicio']
                        : date('Y-m-d');
                    $this->repo->insertarContrato([
                        'persona_id' => $personaId,
                        'fecha_inicio' => $fechaInicio,
                        'proyecto' => $proyecto,
                    ]);
                }

                $this->contexto->guardar(
                    $personaId,
                    (string)$actual['numero_documento'],
                    $contexto['proceso_id'],
                    $proyecto
                );

                return $personaId;
            });
        } catch (PDOException $e) {
            $this->interpretarEscritura($e);
        } catch (Throwable $e) {
            $this->falloPersonal($e, 'No fue posible actualizar el trabajador');
        }

        $actualizado = $this->ver($personaId);
        $cargoCambio = (int)($actual['cargo_id'] ?? 0) !== $cargoId;
        $proyectoAntes = $this->normalizarTexto($actual['proyecto'] ?? '');
        $proyectoAhora = $proyecto ?? '';
        $procesoAntes = (int)($actual['proceso_id'] ?? 0);
        $procesoAhora = $contexto['proceso_id'];
        if (
            $cargoCambio
            || strcasecmp($proyectoAntes, $proyectoAhora) !== 0
            || $procesoAntes !== $procesoAhora
        ) {
            $this->historial->registrarCambio($personaId, $cargoId, $proyecto);
            $actualizado['sincronizacion'] = $this->sincronizarAsignaciones($actualizado);
        }

        if ($actor !== null) {
            $campos = [
                'correo_corporativo' => 'Correo',
                'cargo' => 'Cargo',
                'proyecto' => 'Proyecto',
                'proceso_nombre' => 'Proceso',
            ];
            $antes = $this->auditoria->recortePersonal($actual);
            $despues = $this->auditoria->recortePersonal($actualizado);
            $cambios = $this->auditoria->diff($antes, $despues, $campos);
            if ($cambios !== []) {
                $this->auditoria->deActor(
                    $actor,
                    'actualizar',
                    'personal',
                    $personaId,
                    $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO, [
                        'numero_documento' => $actualizado['numero_documento'] ?? null,
                    ]),
                    $antes
                );
            }
        }

        return $actualizado;
    }

    /**
     * Inactivación lógica. No elimina el registro ni su historial.
     *
     * @param array{usuario_id:?int,nombre:?string,ip:?string} $actor
     * @return array<string,mixed>
     */
    public function inactivar(int $personaId, array $actor): array
    {
        $persona = $this->ver($personaId);
        if (($persona['estado'] ?? '') === 'Inactivo') {
            $persona['ya_inactivo'] = true;

            return $persona;
        }

        try {
            $this->repo->transaccion(function () use ($personaId, $persona, $actor): int {
                $this->repo->actualizarEstado($personaId, 'Inactivo');
                $despues = $this->ver($personaId);
                $cambios = $this->auditoria->diff($persona, $despues, [
                    'estado' => 'Estado laboral',
                    'fecha_inactivacion' => 'Fecha de inactivación',
                ]);
                $this->auditoria->deActor(
                    $actor,
                    'inactivar',
                    'personal',
                    $personaId,
                    $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO),
                    [
                        'estado' => $persona['estado'] ?? null,
                        'fecha_inactivacion' => $persona['fecha_inactivacion'] ?? null,
                    ]
                );

                return $personaId;
            });
        } catch (PDOException $e) {
            $this->interpretarEscritura($e);
        } catch (Throwable $e) {
            $this->falloPersonal($e, 'No fue posible inactivar el trabajador');
        }

        $actualizado = $this->ver($personaId);
        $actualizado['ya_inactivo'] = false;

        return $actualizado;
    }

    /** @return array{activos:int, inactivos:int} */
    public function contarPorEstado(): array
    {
        try {
            return $this->repo->contarPorEstado();
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }
    }

    /**
     * Validación de negocio reutilizada por el formulario y la carga masiva.
     *
     * @param array<string, mixed> $entrada
     * @param array<string, true>|null $documentosEnBd
     * @param array{por_nombre?: array<string,int>, por_id?: array<int,string>}|null $mapaCargos
     * @return array{ok:bool, motivo:?string, datos:?array}
     */
    public function prepararEntrada(
        array $entrada,
        ?int $exceptoPersonaId,
        ?array $documentosEnBd = null,
        bool $consultarDocumentoEnBd = true,
        ?array $mapaCargos = null
    ): array {
        $documento = $this->normalizarDocumento($entrada['numero_documento'] ?? $entrada['documento'] ?? '');

        if ($documento === '') {
            return $this->rechazo('El documento es obligatorio.');
        }

        if (strlen($documento) > self::MAX_DOCUMENTO) {
            return $this->rechazo('El documento no debe exceder 15 caracteres.');
        }

        $nombreCompleto = $this->normalizarTexto($entrada['nombre_completo'] ?? $entrada['nombre'] ?? '');

        if ($nombreCompleto === '') {
            return $this->rechazo('El nombre es obligatorio.');
        }

        $partes = $this->partirNombre($nombreCompleto);

        if ($partes === null) {
            return $this->rechazo('El nombre debe incluir al menos un nombre y un apellido.');
        }

        $correo = $this->normalizarTexto($entrada['correo'] ?? $entrada['correo_corporativo'] ?? '');

        if ($correo !== '' && filter_var($correo, FILTER_VALIDATE_EMAIL) === false) {
            return $this->rechazo('El correo no tiene un formato válido.');
        }

        $cargoId = $this->resolverCargoId($entrada, $mapaCargos);

        if ($cargoId === null) {
            $cargoBruto = $this->normalizarTexto($entrada['cargo'] ?? $entrada['cargo_id'] ?? '');

            return $this->rechazo($cargoBruto === '' ? 'El cargo es obligatorio.' : 'El cargo no existe en el catálogo.');
        }

        $fecha = $this->parsearFecha($entrada['fecha_ingreso'] ?? $entrada['contrato_fecha_inicio'] ?? '');

        if ($fecha === null) {
            $fechaBruta = $this->normalizarTexto($entrada['fecha_ingreso'] ?? $entrada['contrato_fecha_inicio'] ?? '');

            return $this->rechazo($fechaBruta === '' ? 'La fecha de ingreso es obligatoria.' : 'La fecha de ingreso no es válida.');
        }

        $tipoDocumentoId = (int)($entrada['tipo_documento_id'] ?? self::TIPO_DOCUMENTO_CC);

        if ($tipoDocumentoId <= 0) {
            $tipoDocumentoId = self::TIPO_DOCUMENTO_CC;
        }

        try {
            if (!$this->repo->tipoDocumentoExiste($tipoDocumentoId)) {
                return $this->rechazo('El tipo de documento no es válido.');
            }
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }

        $duplicado = false;

        if ($documentosEnBd !== null) {
            $duplicado = isset($documentosEnBd[$documento]);
            if ($exceptoPersonaId !== null && $duplicado) {
                try {
                    $duplicado = $this->repo->existeDocumento($documento, $exceptoPersonaId);
                } catch (Throwable $e) {
                    $this->falloPersonal($e);
                }
            }
        } elseif ($consultarDocumentoEnBd) {
            try {
                $duplicado = $this->repo->existeDocumento($documento, $exceptoPersonaId);
            } catch (Throwable $e) {
                $this->falloPersonal($e);
            }
        }

        if ($duplicado) {
            return $this->rechazo('El documento ya se encuentra registrado.');
        }

        $proyecto = $this->normalizarTexto($entrada['proyecto'] ?? '');
        $contexto = null;
        $procesoRaw = $entrada['proceso_id'] ?? null;
        if ($procesoRaw !== null && $procesoRaw !== '') {
            try {
                $contexto = $this->resolverContextoHseq($entrada);
                $proyecto = $contexto['proyecto'] ?? '';
            } catch (HttpException $e) {
                return $this->rechazo($e->getMessage());
            }
        }

        return [
            'ok' => true,
            'motivo' => null,
            'datos' => [
                'numero_documento' => $documento,
                'tipo_documento_id' => $tipoDocumentoId,
                'nombre_completo' => $nombreCompleto,
                'primer_nombre' => $partes['primer_nombre'],
                'segundo_nombre' => $partes['segundo_nombre'],
                'primer_apellido' => $partes['primer_apellido'],
                'segundo_apellido' => $partes['segundo_apellido'],
                'correo_corporativo' => $correo !== '' ? $correo : null,
                'cargo_id' => $cargoId,
                'proyecto' => $proyecto !== '' ? $proyecto : null,
                'proceso_id' => $contexto['proceso_id'] ?? null,
                'fecha_ingreso' => $fecha,
                'fecha_nacimiento_texto' => self::FECHA_NACIMIENTO_TECNICA,
                'estado' => 'Activo',
            ],
        ];
    }

    /**
     * @param array<string, mixed> $datos
     */
    public function persistirAlta(array $datos): int
    {
        try {
            $personaId = $this->repo->transaccion(function () use ($datos): int {
                $personaId = $this->repo->insertarPersona([
                    'numero_documento' => $datos['numero_documento'],
                    'tipo_documento_id' => $datos['tipo_documento_id'],
                    'primer_nombre' => $datos['primer_nombre'],
                    'segundo_nombre' => $datos['segundo_nombre'],
                    'primer_apellido' => $datos['primer_apellido'],
                    'segundo_apellido' => $datos['segundo_apellido'],
                    'fecha_nacimiento_texto' => $datos['fecha_nacimiento_texto'],
                    'correo_corporativo' => $datos['correo_corporativo'],
                    'cargo_id' => $datos['cargo_id'],
                    'estado' => $datos['estado'],
                ]);

                $this->repo->insertarContrato([
                    'persona_id' => $personaId,
                    'fecha_inicio' => $datos['fecha_ingreso'],
                    'proyecto' => $datos['proyecto'],
                ]);

                if (!empty($datos['proceso_id'])) {
                    $this->contexto->guardar(
                        $personaId,
                        (string)$datos['numero_documento'],
                        (int)$datos['proceso_id'],
                        isset($datos['proyecto']) && is_string($datos['proyecto']) ? $datos['proyecto'] : null
                    );
                }

                return $personaId;
            });
        } catch (PDOException $e) {
            $this->interpretarEscritura($e);
        } catch (Throwable $e) {
            $this->falloPersonal($e, 'No fue posible registrar el trabajador');
        }

        $fecha = is_string($datos['fecha_ingreso'] ?? null) && $datos['fecha_ingreso'] !== ''
            ? (string)$datos['fecha_ingreso']
            : date('Y-m-d');
        $proyecto = isset($datos['proyecto']) && is_string($datos['proyecto']) && $datos['proyecto'] !== ''
            ? (string)$datos['proyecto']
            : null;
        $this->historial->registrarAlta(
            $personaId,
            isset($datos['cargo_id']) ? (int)$datos['cargo_id'] : null,
            $proyecto,
            $fecha
        );

        return $personaId;
    }

    /**
     * @param array<string,mixed> $persona
     * @return array{creadas:int, omitidas:int, creadas_especiales:list<string>, error:?string}
     */
    public function sincronizarAsignaciones(array $persona): array
    {
        try {
            $resultado = $this->motorAsignacion()->sincronizarPersona($persona, null);
            $especiales = [];
            foreach ($resultado['creadas_especiales'] ?? [] as $nombre) {
                if (is_string($nombre) && $nombre !== '') {
                    $especiales[] = $nombre;
                }
            }

            return [
                'creadas' => (int)$resultado['creadas'],
                'omitidas' => (int)$resultado['omitidas'],
                'creadas_especiales' => $especiales,
                'error' => null,
            ];
        } catch (Throwable $e) {
            Logger::error('RF-008 no pudo sincronizar al trabajador', [
                'persona_id' => $persona['persona_id'] ?? null,
                'cargo_id' => $persona['cargo_id'] ?? null,
                'proyecto' => $persona['proyecto'] ?? null,
                'error' => $e->getMessage(),
            ]);

            return [
                'creadas' => 0,
                'omitidas' => 0,
                'creadas_especiales' => [],
                'error' => 'El trabajador fue registrado, pero ocurrió un problema al generar sus asignaciones de capacitación. Consulte el historial o contacte al administrador.',
            ];
        }
    }

    public function repositorio(): PersonalRepository
    {
        return $this->repo;
    }

    public function normalizarDocumento(mixed $valor): string
    {
        $texto = $this->normalizarTexto($valor);
        $texto = str_replace(["\u{00A0}", ' '], '', $texto);

        if (preg_match('/^\d{1,3}(\.\d{3})+$/', $texto) === 1) {
            $texto = str_replace('.', '', $texto);
        }

        return $texto;
    }

    public function normalizarTexto(mixed $valor): string
    {
        if ($valor === null) {
            return '';
        }

        if (is_float($valor) || is_int($valor)) {
            if ((float)$valor == floor((float)$valor)) {
                return sprintf('%.0f', $valor);
            }

            return trim((string)$valor);
        }

        $texto = trim((string)$valor);
        $texto = preg_replace('/\s+/u', ' ', $texto) ?? $texto;

        return trim($texto);
    }

    /**
     * @return array{primer_nombre:string, segundo_nombre:?string, primer_apellido:string, segundo_apellido:?string}|null
     */
    public function partirNombre(string $nombreCompleto): ?array
    {
        $tokens = preg_split('/\s+/u', trim($nombreCompleto)) ?: [];
        $tokens = array_values(array_filter($tokens, static fn ($t) => $t !== ''));

        if (count($tokens) < 2) {
            return null;
        }

        $limite = 50;
        $cortar = static function (string $valor) use ($limite): string {
            if (function_exists('mb_substr')) {
                return mb_substr($valor, 0, $limite, 'UTF-8');
            }

            return substr($valor, 0, $limite);
        };

        $primerNombre = $cortar($tokens[0]);
        $segundoNombre = null;
        $primerApellido = null;
        $segundoApellido = null;

        if (count($tokens) === 2) {
            $primerApellido = $cortar($tokens[1]);
        } elseif (count($tokens) === 3) {
            $segundoNombre = $cortar($tokens[1]);
            $primerApellido = $cortar($tokens[2]);
        } else {
            $segundoApellido = $cortar($tokens[count($tokens) - 1]);
            $primerApellido = $cortar($tokens[count($tokens) - 2]);
            $medio = array_slice($tokens, 1, count($tokens) - 3);
            $segundoNombre = $cortar(implode(' ', $medio));
        }

        return [
            'primer_nombre' => $primerNombre,
            'segundo_nombre' => $segundoNombre !== '' ? $segundoNombre : null,
            'primer_apellido' => (string)$primerApellido,
            'segundo_apellido' => $segundoApellido !== '' && $segundoApellido !== null ? $segundoApellido : null,
        ];
    }

    public function parsearFecha(mixed $valor): ?string
    {
        if ($valor === null || $valor === '') {
            return null;
        }

        if ($valor instanceof \DateTimeInterface) {
            return $valor->format('Y-m-d');
        }

        if (is_int($valor) || (is_float($valor) && (float)$valor == floor((float)$valor))) {
            return $this->fechaDesdeSerialExcel((int)$valor);
        }

        $texto = $this->normalizarTexto($valor);

        if ($texto === '') {
            return null;
        }

        if (is_numeric($texto) && strpos($texto, '.') === false && (int)$texto > 20000 && (int)$texto < 80000) {
            return $this->fechaDesdeSerialExcel((int)$texto);
        }

        $formatos = ['Y-m-d', 'd/m/Y', 'd-m-Y', 'd/m/y', 'd-m-y'];

        foreach ($formatos as $formato) {
            $fecha = \DateTimeImmutable::createFromFormat('!' . $formato, $texto);
            $errores = \DateTimeImmutable::getLastErrors();

            if ($fecha instanceof \DateTimeImmutable && $errores && $errores['warning_count'] === 0 && $errores['error_count'] === 0) {
                return $fecha->format('Y-m-d');
            }

            if ($fecha instanceof \DateTimeImmutable && $errores === false) {
                return $fecha->format('Y-m-d');
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $entrada
     */
    public function resolverCargoId(array $entrada, ?array $mapaCargos = null): ?int
    {
        if (isset($entrada['cargo_id']) && $entrada['cargo_id'] !== '' && $entrada['cargo_id'] !== null) {
            $id = (int)$entrada['cargo_id'];

            if ($id <= 0) {
                return null;
            }

            if ($mapaCargos !== null) {
                return isset($mapaCargos['por_id'][$id]) ? $id : null;
            }

            try {
                return $this->repo->cargoExiste($id) ? $id : null;
            } catch (Throwable $e) {
                $this->falloPersonal($e);
            }
        }

        $cargoTexto = $this->normalizarTexto($entrada['cargo'] ?? '');

        if ($cargoTexto === '') {
            return null;
        }

        if (preg_match('/^\d+$/', $cargoTexto) === 1) {
            $id = (int)$cargoTexto;

            if ($mapaCargos !== null) {
                return isset($mapaCargos['por_id'][$id]) ? $id : null;
            }

            try {
                return $this->repo->cargoExiste($id) ? $id : null;
            } catch (Throwable $e) {
                $this->falloPersonal($e);
            }
        }

        $clave = $this->repo->claveCargo($cargoTexto);

        if ($mapaCargos !== null) {
            return $mapaCargos['por_nombre'][$clave] ?? null;
        }

        try {
            $mapa = $this->repo->mapaCargos();
        } catch (Throwable $e) {
            $this->falloPersonal($e);
        }

        return $mapa['por_nombre'][$clave] ?? null;
    }

    private function fechaDesdeSerialExcel(int $serial): ?string
    {
        if ($serial < 1) {
            return null;
        }

        $unix = ($serial - 25569) * 86400;
        $fecha = gmdate('Y-m-d', $unix);

        return $fecha !== false ? $fecha : null;
    }

    /** @return array{ok:bool, motivo:string, datos:null} */
    private function rechazo(string $motivo): array
    {
        return ['ok' => false, 'motivo' => $motivo, 'datos' => null];
    }

    private function codigoHttp(string $motivo): int
    {
        if ($motivo === 'El documento ya se encuentra registrado.') {
            return 409;
        }

        return 422;
    }

    private function interpretarEscritura(PDOException $e): void
    {
        if (PersonalRepository::esConflictoUnico($e)) {
            throw new HttpException('El documento ya se encuentra registrado.', 409);
        }

        Logger::error('Error al escribir personal corporativo: ' . $e->getMessage());
        throw new HttpException('No fue posible guardar el trabajador', 500);
    }

    private function falloPersonal(Throwable $e, string $mensaje = 'No fue posible consultar el maestro de personal corporativo'): void
    {
        if ($e instanceof HttpException) {
            throw $e;
        }

        Logger::error($mensaje . ': ' . $e->getMessage());

        throw new HttpException(
            $mensaje,
            $e instanceof PDOException ? 503 : 500
        );
    }

    private function matriz(): MatrizRepository
    {
        return $this->matriz ??= new MatrizRepository();
    }

    private function alertasRepo(): AlertaRepository
    {
        return $this->alertasRepo ??= new AlertaRepository();
    }

    private function proyectoListado(?int $procesoId, ?string $proyecto): ?string
    {
        $normalizado = nullable_trimmed_string($proyecto);
        if ($normalizado === null || $normalizado === '') {
            return null;
        }

        if ($procesoId !== null && $procesoId > 0 && !$this->alertasRepo()->procesoEsGestionProyectos($procesoId)) {
            return null;
        }

        $canonico = $this->alertasRepo()->resolverProyecto($normalizado, false);
        if ($canonico === null) {
            throw new HttpException('El proyecto no es válido.', 422);
        }

        return $canonico;
    }

    /**
     * @param list<array<string,mixed>> $items
     * @return list<array<string,mixed>>
     */
    private function adjuntarProcesos(array $items): array
    {
        $cargoIds = [];
        $personaIds = [];
        foreach ($items as $item) {
            $cargoId = isset($item['cargo_id']) ? (int)$item['cargo_id'] : 0;
            if ($cargoId > 0) {
                $cargoIds[] = $cargoId;
            }
            $personaId = isset($item['persona_id']) ? (int)$item['persona_id'] : 0;
            if ($personaId > 0) {
                $personaIds[] = $personaId;
            }
        }

        $filas = $this->matriz()->procesosDeCargos($cargoIds);
        $contextos = $this->contexto->mapaPorPersonaIds($personaIds);
        $salida = [];
        foreach ($items as $item) {
            $personaId = isset($item['persona_id']) ? (int)$item['persona_id'] : 0;
            $ctx = $contextos[$personaId] ?? null;
            $proyectoItem = is_string($item['proyecto'] ?? null) ? (string)$item['proyecto'] : null;
            if ($ctx !== null && ($ctx['proyecto'] ?? null) !== null && $ctx['proyecto'] !== '') {
                $proyectoItem = $ctx['proyecto'];
                $item['proyecto'] = $ctx['proyecto'];
            }
            $procesos = $this->procesosDeItem(
                $filas,
                isset($item['cargo_id']) ? (int)$item['cargo_id'] : 0,
                $proyectoItem
            );
            if ($ctx !== null) {
                $item['proceso_id'] = $ctx['proceso_id'];
                $item['proceso_nombre'] = $ctx['proceso_nombre'];
                $procesos = $this->sumarProcesoExplicito($procesos, $ctx['proceso_id'], $ctx['proceso_nombre']);
            } else {
                $item['proceso_id'] = null;
                $item['proceso_nombre'] = null;
            }
            $item['procesos'] = $procesos;
            $salida[] = $item;
        }

        return $salida;
    }

    /**
     * @param list<array{proceso_id:int,nombre:string}> $procesos
     * @return list<array{proceso_id:int,nombre:string}>
     */
    private function sumarProcesoExplicito(array $procesos, int $procesoId, string $nombre): array
    {
        foreach ($procesos as $proceso) {
            if ((int)$proceso['proceso_id'] === $procesoId) {
                return $procesos;
            }
        }
        $procesos[] = [
            'proceso_id' => $procesoId,
            'nombre' => $nombre,
        ];

        return $procesos;
    }

    /**
     * @param array<string,mixed> $entrada
     * @return array{proceso_id:int,proyecto:?string}
     */
    private function resolverContextoHseq(array $entrada): array
    {
        $procesoId = isset($entrada['proceso_id']) ? (int)$entrada['proceso_id'] : 0;
        if ($procesoId < 1) {
            throw new HttpException('El proceso es obligatorio.', 422);
        }

        $procesos = $this->alertasRepo()->procesosActivos();
        $encontrado = null;
        foreach ($procesos as $proceso) {
            if ((int)$proceso['proceso_id'] === $procesoId) {
                $encontrado = $proceso;
                break;
            }
        }
        if ($encontrado === null) {
            throw new HttpException('El proceso no existe o no está activo.', 422);
        }

        $requiereProyecto = $this->alertasRepo()->procesoEsGestionProyectos($procesoId);
        $proyectoBruto = $this->normalizarTexto($entrada['proyecto'] ?? '');

        if ($requiereProyecto) {
            if ($proyectoBruto === '') {
                throw new HttpException('El proyecto es obligatorio para este proceso.', 422);
            }
            $canonico = $this->alertasRepo()->resolverProyecto($proyectoBruto, false);
            if ($canonico === null) {
                throw new HttpException('El proyecto no es válido.', 422);
            }

            return [
                'proceso_id' => $procesoId,
                'proyecto' => $canonico,
            ];
        }

        return [
            'proceso_id' => $procesoId,
            'proyecto' => null,
        ];
    }

    /**
     * @param list<array{cargo_id:int,proyecto:?string,proceso_id:int,proceso_nombre:string}> $filas
     * @return list<array{proceso_id:int,nombre:string}>
     */
    private function procesosDeItem(array $filas, int $cargoId, ?string $proyecto): array
    {
        if ($cargoId < 1) {
            return [];
        }

        $vistos = [];
        $salida = [];
        foreach ($filas as $fila) {
            if ((int)$fila['cargo_id'] !== $cargoId) {
                continue;
            }
            $filaProyecto = $fila['proyecto'];
            if ($filaProyecto !== null && ($proyecto === null || $proyecto === '')) {
                continue;
            }
            if ($filaProyecto !== null && strcasecmp($filaProyecto, (string)$proyecto) !== 0) {
                continue;
            }
            $procesoId = (int)$fila['proceso_id'];
            if (isset($vistos[$procesoId])) {
                continue;
            }
            $vistos[$procesoId] = true;
            $salida[] = [
                'proceso_id' => $procesoId,
                'nombre' => (string)$fila['proceso_nombre'],
            ];
        }

        return $salida;
    }

    /**
     * @param array<string,mixed> $fila
     * @return array<string,mixed>
     */
    private function normalizarAplicable(array $fila): array
    {
        return [
            'matriz_aplicabilidad_id' => isset($fila['matriz_aplicabilidad_id'])
                ? (int)$fila['matriz_aplicabilidad_id']
                : null,
            'capacitacion_id' => isset($fila['capacitacion_id']) ? (int)$fila['capacitacion_id'] : null,
            'capacitacion_codigo' => $fila['capacitacion_codigo'] ?? null,
            'capacitacion_nombre' => $fila['capacitacion_nombre'] ?? null,
            'proceso_id' => isset($fila['proceso_id']) && $fila['proceso_id'] !== null
                ? (int)$fila['proceso_id']
                : null,
            'proceso_nombre' => $fila['proceso_nombre'] ?? null,
            'proyecto' => $fila['proyecto'] ?? null,
            'periodicidad_nombre' => humanizar_nombre_unidad($fila['periodicidad_nombre'] ?? null),
        ];
    }

    private function normalizar(array $fila): array
    {
        return [
            'persona_id' => (int)$fila['persona_id'],
            'numero_documento' => $fila['numero_documento'],
            'tipo_documento_id' => isset($fila['tipo_documento_id']) ? (int)$fila['tipo_documento_id'] : null,
            'tipo_documento_nombre' => $fila['tipo_documento_nombre'] ?? null,
            'tipo_documento_abreviatura' => $fila['tipo_documento_abreviatura'] ?? null,
            'nombre_completo' => $fila['nombre_completo'],
            'estado' => $fila['estado'],
            'fecha_inactivacion' => $fila['fecha_inactivacion'] ?? null,
            'cargo_id' => $fila['cargo_id'] !== null ? (int)$fila['cargo_id'] : null,
            'cargo' => $fila['cargo'],
            'correo_corporativo' => $fila['correo_corporativo'],
            'correo_personal' => $fila['correo_personal'],
            'celular' => $fila['celular'],
            'contrato_id' => $fila['contrato_id'] !== null ? (int)$fila['contrato_id'] : null,
            'numero_contrato' => $fila['numero_contrato'],
            'proyecto' => $fila['proyecto'],
            'contrato_fecha_inicio' => $fila['contrato_fecha_inicio'],
            'contrato_fecha_terminacion' => $fila['contrato_fecha_terminacion'],
            'proceso_id' => null,
            'proceso_nombre' => null,
            'procesos' => [],
        ];
    }
}
