<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Services\AuditoriaService;
use App\Services\PlanAnualService;

class PlanAnualController extends Controller
{
    private PlanAnualService $service;
    private AuditoriaService $auditoria;

    public function __construct()
    {
        $this->service = new PlanAnualService();
        $this->auditoria = new AuditoriaService();
    }

    public function index(Request $request): void
    {
        $anioRaw = $request->query('anio');
        $procesoRaw = $request->query('proceso_id');
        $resultado = $this->service->listar(
            (int)$request->query('page', 1),
            (int)$request->query('per_page', 20),
            ($anioRaw !== null && $anioRaw !== '') ? (int)$anioRaw : null,
            nullable_trimmed_string($request->query('estado')),
            nullable_trimmed_string($request->query('buscar')),
            ($procesoRaw !== null && $procesoRaw !== '') ? (int)$procesoRaw : null,
            nullable_trimmed_string($request->query('proyecto'))
        );

        $this->paginate($resultado['items'], $resultado['total'], $resultado['page'], $resultado['per_page']);
    }

    public function opciones(Request $request): void
    {
        $this->success($this->service->opciones());
    }

    public function alcance(Request $request): void
    {
        $capRaw = $request->query('capacitacion_id');
        $procesoRaw = $request->query('proceso_id');
        $this->success(
            $this->service->alcance(
                ($capRaw !== null && $capRaw !== '') ? (int)$capRaw : 0,
                ($procesoRaw !== null && $procesoRaw !== '') ? (int)$procesoRaw : 0,
                nullable_trimmed_string($request->query('proyecto'))
            )
        );
    }

    public function show(Request $request, string $id): void
    {
        $this->success($this->service->ver((int)$id));
    }

    public function store(Request $request): void
    {
        $datos = $this->validate($request, [
            'anio' => 'required|integer|min:2000|max:2100',
        ]);
        $creado = $this->service->crear($datos, $request->userId());

        $this->auditoria->dePeticion(
            $request,
            'crear',
            'planes_anuales',
            (int)$creado['plan_anual_id'],
            $creado
        );

        $this->created($creado, 'Plan Anual guardado correctamente.');
    }

    public function crearActividad(Request $request, string $id): void
    {
        $datos = $this->validate($request, $this->service->reglasActividad());
        $plan = $this->service->crearActividad((int)$id, $datos);

        $this->auditoria->dePeticion(
            $request,
            'crear_actividad',
            'plan_anual_detalle',
            (int)$id,
            [
                'plan_anual_id' => (int)$id,
                'capacitacion_id' => (int)($datos['capacitacion_id'] ?? 0),
                'proceso_id' => isset($datos['proceso_id']) ? (int)$datos['proceso_id'] : null,
                'proyecto' => $datos['proyecto'] ?? null,
            ]
        );

        $this->success($plan, 'Capacitación contemplada en el Plan Anual.');
    }

    public function verActividad(Request $request, string $id, string $detalleId): void
    {
        $this->success($this->service->verActividad((int)$id, (int)$detalleId));
    }

    public function actualizarActividad(Request $request, string $id, string $detalleId): void
    {
        $datos = $this->validate($request, $this->service->reglasActividad());
        $anterior = $this->service->verActividad((int)$id, (int)$detalleId);
        $plan = $this->service->actualizarActividad((int)$id, (int)$detalleId, $datos);
        $despues = $this->service->verActividad((int)$id, (int)$detalleId);
        $campos = [
            'capacitacion_nombre' => 'Capacitación',
            'proceso_nombre' => 'Proceso',
            'proyecto' => 'Proyecto',
            'fecha_programada' => 'Fecha programada',
        ];
        $cambios = $this->auditoria->diff($anterior, $despues, $campos);
        $this->auditoria->dePeticion(
            $request,
            'editar_actividad',
            'plan_anual_detalle',
            (int)$detalleId,
            $this->auditoria->payloadNuevo($cambios, AuditoriaService::ORIGEN_USUARIO, [
                'plan_anual_id' => (int)$id,
            ]),
            [
                'capacitacion_nombre' => $anterior['capacitacion_nombre'] ?? null,
                'proceso_nombre' => $anterior['proceso_nombre'] ?? null,
                'proyecto' => $anterior['proyecto'] ?? null,
                'fecha_programada' => $anterior['fecha_programada'] ?? null,
            ]
        );

        $this->success($plan, 'Plan Anual guardado correctamente.');
    }

    public function eliminarActividad(Request $request, string $id, string $detalleId): void
    {
        $anterior = $this->service->verActividad((int)$id, (int)$detalleId);
        $plan = $this->service->eliminarActividad((int)$id, (int)$detalleId);

        $this->auditoria->dePeticion(
            $request,
            'eliminar_actividad',
            'plan_anual_detalle',
            (int)$detalleId,
            ['plan_anual_id' => (int)$id],
            [
                'capacitacion_nombre' => $anterior['capacitacion_nombre'] ?? null,
                'proceso_nombre' => $anterior['proceso_nombre'] ?? null,
                'proyecto' => $anterior['proyecto'] ?? null,
                'fecha_programada' => $anterior['fecha_programada'] ?? null,
            ]
        );

        $this->success($plan, 'Capacitación retirada del Plan Anual.');
    }

    public function disponibles(Request $request, string $id): void
    {
        $resultado = $this->service->disponibles(
            (int)$id,
            nullable_trimmed_string($request->query('buscar'))
        );

        $this->success($resultado, 'Asignaciones disponibles para el plan');
    }

    public function incluir(Request $request, string $id): void
    {
        $datos = $this->validate($request, [
            'asignacion_ids' => 'required|array',
            'mes_programado' => 'required|integer|min:1|max:12',
        ]);
        $resultado = $this->service->incluirAsignaciones((int)$id, $datos);

        $this->auditoria->dePeticion(
            $request,
            'incluir_asignaciones',
            'planes_anuales',
            (int)$id,
            $resultado
        );

        $this->success($resultado, $this->service->mensajeInclusion($resultado));
    }

    public function quitarAsignacion(Request $request, string $id, string $asignacionId): void
    {
        $actualizado = $this->service->quitarAsignacion((int)$id, (int)$asignacionId);

        $this->auditoria->dePeticion(
            $request,
            'quitar_asignacion',
            'planes_anuales',
            (int)$id,
            ['asignacion_id' => (int)$asignacionId]
        );

        $this->success($actualizado, 'Asignación retirada del plan');
    }

    public function moverAsignacion(Request $request, string $id, string $asignacionId): void
    {
        $datos = $this->validate($request, [
            'mes_programado' => 'required|integer|min:1|max:12',
        ]);
        $actualizado = $this->service->moverAsignacion(
            (int)$id,
            (int)$asignacionId,
            (int)$datos['mes_programado']
        );

        $this->auditoria->dePeticion(
            $request,
            'mover_asignacion',
            'planes_anuales',
            (int)$id,
            ['asignacion_id' => (int)$asignacionId, 'mes_programado' => (int)$datos['mes_programado']]
        );

        $this->success($actualizado, 'Mes de programación actualizado');
    }

    public function enviarRevision(Request $request, string $id): void
    {
        $plan = $this->service->enviarRevision((int)$id);

        $this->auditoria->dePeticion(
            $request,
            'enviar_revision',
            'planes_anuales',
            (int)$id,
            ['estado_anterior' => 'BORRADOR', 'estado_nuevo' => 'EN_REVISION']
        );

        $this->success($plan, 'Plan Anual enviado a aprobación.');
    }

    public function devolver(Request $request, string $id): void
    {
        $plan = $this->service->devolver((int)$id);

        $this->auditoria->dePeticion(
            $request,
            'devolver',
            'planes_anuales',
            (int)$id,
            ['estado_anterior' => 'EN_REVISION', 'estado_nuevo' => 'BORRADOR']
        );

        $this->success($plan, 'Plan Anual devuelto para corrección.');
    }

    public function aprobar(Request $request, string $id): void
    {
        $plan = $this->service->aprobar((int)$id, $request->userId());

        $this->auditoria->dePeticion(
            $request,
            'aprobar',
            'planes_anuales',
            (int)$id,
            ['estado_anterior' => 'EN_REVISION', 'estado_nuevo' => 'APROBADO']
        );

        $this->success($plan, 'Plan Anual aprobado correctamente.');
    }
}
