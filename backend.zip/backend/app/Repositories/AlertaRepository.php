<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;

/**
 * Alertas alineadas con vw_alertas_vencimiento.
 * Incluye pendientes y vigencias próximas/vencidas (ventana 30 días en la vista).
 */
class AlertaRepository
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * @param array<string,mixed> $filtros
     * @return list<array<string,mixed>>
     */
    public function listar(int $limite, int $offset, array $filtros): array
    {
        [$where, $params] = $this->filtros($filtros);
        $personas = Database::personalTable('personas');
        $cargos = Database::personalTable('cargos');

        $cargoSql = ContextoLaboralSql::cargoId();
        $procesoSql = ContextoLaboralSql::procesoId();

        return $this->db->fetchAll(
            "SELECT v.asignacion_id,
                    v.persona_id_ext,
                    v.capacitacion_id,
                    {$procesoSql} AS proceso_id,
                    {$cargoSql} AS cargo_id_ext,
                    v.proyecto,
                    a.fecha_asignacion,
                    v.fecha_limite_cumplimiento,
                    v.fecha_realizacion,
                    v.fecha_vencimiento,
                    v.estado_calculado,
                    v.tipo_alerta,
                    v.fecha_alerta,
                    v.cumplimiento_id,
                    DATEDIFF(v.fecha_alerta, CURDATE()) AS dias_restantes,
                    cap.codigo AS capacitacion_codigo,
                    cap.nombre AS capacitacion_nombre,
                    cap.certificado AS capacitacion_certificado,
                    cap.es_tarea_critica,
                    per_cat.nombre AS periodicidad_nombre,
                    cump.nota_evaluacion,
                    cump.resultado AS cumplimiento_resultado,
                    (SELECT COUNT(*) FROM soportes_cumplimiento s WHERE s.cumplimiento_id = v.cumplimiento_id) AS soportes_count,
                    proc.nombre AS proceso_nombre,
                    per.numero_documento,
                    per.nombre_completo_nombres_primero AS persona_nombre,
                    car.nombre_cargo
             FROM vw_alertas_vencimiento v
             INNER JOIN asignaciones_capacitacion a ON a.asignacion_id = v.asignacion_id
             INNER JOIN {$personas} per ON per.persona_id = v.persona_id_ext AND per.estado = 'Activo'
             LEFT JOIN cumplimientos_capacitacion cump ON cump.cumplimiento_id = v.cumplimiento_id
             LEFT JOIN capacitaciones cap ON cap.capacitacion_id = v.capacitacion_id
             LEFT JOIN periodicidades per_cat ON per_cat.periodicidad_id = cap.periodicidad_default_id
             LEFT JOIN procesos proc ON proc.proceso_id = {$procesoSql}
             LEFT JOIN {$cargos} car ON car.cargo_id = {$cargoSql}
             {$where}
             ORDER BY
               CASE
                 WHEN DATEDIFF(v.fecha_alerta, CURDATE()) < 0 THEN 1
                 WHEN DATEDIFF(v.fecha_alerta, CURDATE()) = 0 THEN 2
                 WHEN DATEDIFF(v.fecha_alerta, CURDATE()) BETWEEN 1 AND 7 THEN 3
                 WHEN DATEDIFF(v.fecha_alerta, CURDATE()) BETWEEN 8 AND 15 THEN 4
                 ELSE 5
               END ASC,
               v.fecha_alerta ASC,
               v.asignacion_id ASC
             LIMIT {$limite} OFFSET {$offset}",
            $params
        );
    }

    /**
     * @param array<string,mixed> $filtros
     */
    public function contar(array $filtros): int
    {
        [$where, $params] = $this->filtros($filtros);
        $fila = $this->db->fetch(
            "SELECT COUNT(*) AS total
             FROM vw_alertas_vencimiento v
             INNER JOIN asignaciones_capacitacion a ON a.asignacion_id = v.asignacion_id
             INNER JOIN " . Database::personalTable('personas') . " per ON per.persona_id = v.persona_id_ext AND per.estado = 'Activo'
             {$where}",
            $params
        );

        return (int)($fila['total'] ?? 0);
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array{
     *   vencidas:int,
     *   proximas_30:int,
     *   plazo_vencidas:int,
     *   plazo_proximas:int,
     *   vigencia_vencidas:int,
     *   vigencia_proximas:int
     * }
     */
    public function resumen(array $filtros): array
    {
        [$where, $params] = $this->filtros($filtros);
        $personas = Database::personalTable('personas');

        $fila = $this->db->fetch(
            "SELECT
                COALESCE(SUM(CASE
                    WHEN DATEDIFF(v.fecha_alerta, CURDATE()) < 0 THEN 1
                    ELSE 0
                END), 0) AS vencidas,
                COALESCE(SUM(CASE
                    WHEN DATEDIFF(v.fecha_alerta, CURDATE()) BETWEEN 0 AND 30 THEN 1
                    ELSE 0
                END), 0) AS proximas_30,
                COALESCE(SUM(CASE
                    WHEN v.tipo_alerta = 'LIMITE_CUMPLIMIENTO'
                     AND DATEDIFF(v.fecha_limite_cumplimiento, CURDATE()) < 0 THEN 1
                    ELSE 0
                END), 0) AS plazo_vencidas,
                COALESCE(SUM(CASE
                    WHEN v.tipo_alerta = 'LIMITE_CUMPLIMIENTO'
                     AND DATEDIFF(v.fecha_limite_cumplimiento, CURDATE()) BETWEEN 0 AND 30 THEN 1
                    ELSE 0
                END), 0) AS plazo_proximas,
                COALESCE(SUM(CASE
                    WHEN v.tipo_alerta = 'VIGENCIA_CUMPLIMIENTO'
                     AND DATEDIFF(v.fecha_vencimiento, CURDATE()) < 0 THEN 1
                    ELSE 0
                END), 0) AS vigencia_vencidas,
                COALESCE(SUM(CASE
                    WHEN v.tipo_alerta = 'VIGENCIA_CUMPLIMIENTO'
                     AND DATEDIFF(v.fecha_vencimiento, CURDATE()) BETWEEN 0 AND 30 THEN 1
                    ELSE 0
                END), 0) AS vigencia_proximas
             FROM vw_alertas_vencimiento v
             INNER JOIN asignaciones_capacitacion a ON a.asignacion_id = v.asignacion_id
             INNER JOIN {$personas} per ON per.persona_id = v.persona_id_ext AND per.estado = 'Activo'
             {$where}",
            $params
        );

        return [
            'vencidas' => (int)($fila['vencidas'] ?? 0),
            'proximas_30' => (int)($fila['proximas_30'] ?? 0),
            'plazo_vencidas' => (int)($fila['plazo_vencidas'] ?? 0),
            'plazo_proximas' => (int)($fila['plazo_proximas'] ?? 0),
            'vigencia_vencidas' => (int)($fila['vigencia_vencidas'] ?? 0),
            'vigencia_proximas' => (int)($fila['vigencia_proximas'] ?? 0),
        ];
    }

    /** @return list<array{proceso_id:int,nombre:string}> */
    public function procesosActivos(): array
    {
        $filas = $this->db->fetchAll(
            'SELECT proceso_id, nombre FROM procesos WHERE activo = 1 ORDER BY nombre ASC'
        );

        $salida = [];
        foreach ($filas as $fila) {
            $salida[] = [
                'proceso_id' => (int)$fila['proceso_id'],
                'nombre' => (string)$fila['nombre'],
            ];
        }

        return $salida;
    }

    public function procesoEsGestionProyectos(?int $procesoId): bool
    {
        if ($procesoId === null || $procesoId < 1) {
            return false;
        }

        $fila = $this->db->fetch(
            'SELECT nombre FROM procesos WHERE proceso_id = ? LIMIT 1',
            [$procesoId]
        );
        if ($fila === null) {
            return false;
        }

        return $this->nombreEsProcesoDeProyectos((string)$fila['nombre']);
    }

    public function nombreEsProcesoDeProyectos(string $nombre): bool
    {
        $clave = $this->normalizarNombre($nombre);
        if ($clave === 'PROYECTOS') {
            return true;
        }

        return str_contains($clave, 'GESTION DE PROYECTOS');
    }

    /**
     * @return list<array{cargo_id:int|string,nombre_cargo:string}>
     */
    public function cargos(): array
    {
        $cargos = Database::personalTable('cargos');

        return $this->db->fetchAll(
            "SELECT cargo_id, nombre_cargo
             FROM {$cargos}
             ORDER BY nombre_cargo ASC"
        );
    }

    /** @return list<string> */
    public function proyectos(): array
    {
        $filas = $this->db->fetchAll(
            'SELECT nombre FROM proyectos WHERE activo = 1 ORDER BY nombre ASC'
        );

        $salida = [];
        foreach ($filas as $fila) {
            $nombre = trim((string)($fila['nombre'] ?? ''));
            if ($nombre !== '') {
                $salida[] = $nombre;
            }
        }

        return $salida;
    }

    /**
     * Devuelve el nombre canónico del catálogo, o null si no existe / no está vigente.
     */
    public function resolverProyecto(?string $nombre, bool $soloActivos = true): ?string
    {
        $bruto = trim((string)$nombre);
        if ($bruto === '') {
            return null;
        }

        $sql = 'SELECT nombre, activo FROM proyectos';
        $clave = $this->normalizarNombre($bruto);
        foreach ($this->db->fetchAll($sql) as $fila) {
            if ($this->normalizarNombre((string)$fila['nombre']) !== $clave) {
                continue;
            }
            if ($soloActivos && (int)($fila['activo'] ?? 0) !== 1) {
                return null;
            }

            return (string)$fila['nombre'];
        }

        return null;
    }

    /**
     * @return list<array{capacitacion_id:int,codigo:string,nombre:string}>
     */
    public function capacitacionesEnAlertas(): array
    {
        $personas = Database::personalTable('personas');
        $filas = $this->db->fetchAll(
            "SELECT DISTINCT cap.capacitacion_id, cap.codigo, cap.nombre
             FROM vw_alertas_vencimiento v
             INNER JOIN asignaciones_capacitacion a ON a.asignacion_id = v.asignacion_id
             INNER JOIN {$personas} per ON per.persona_id = v.persona_id_ext AND per.estado = 'Activo'
             INNER JOIN capacitaciones cap ON cap.capacitacion_id = v.capacitacion_id
             ORDER BY cap.nombre ASC"
        );

        $salida = [];
        foreach ($filas as $fila) {
            $salida[] = [
                'capacitacion_id' => (int)$fila['capacitacion_id'],
                'codigo' => (string)$fila['codigo'],
                'nombre' => (string)$fila['nombre'],
            ];
        }

        return $salida;
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array{0:string,1:list<mixed>}
     */
    private function filtros(array $filtros): array
    {
        $condiciones = [];
        $params = [];

        // Vigencia: solo el ciclo más reciente por persona+capacitación (RF-CI-056).
        $condiciones[] = "(v.tipo_alerta COLLATE utf8mb4_unicode_ci = 'LIMITE_CUMPLIMIENTO'
            OR NOT EXISTS (
                SELECT 1
                FROM cumplimientos_capacitacion c2
                INNER JOIN asignaciones_capacitacion a2 ON a2.asignacion_id = c2.asignacion_id
                WHERE a2.persona_id_ext = v.persona_id_ext
                  AND a2.capacitacion_id = v.capacitacion_id
                  AND c2.resultado COLLATE utf8mb4_unicode_ci = 'APROBADO'
                  AND c2.fecha_realizacion > v.fecha_realizacion
            ))";

        $personaId = $filtros['persona_id'] ?? $filtros['persona_id_ext'] ?? null;
        if ($personaId !== null && (int)$personaId > 0) {
            $condiciones[] = 'v.persona_id_ext = ?';
            $params[] = (int)$personaId;
        }

        $procesoId = $filtros['proceso_id'] ?? null;
        if ($procesoId !== null && $procesoId > 0) {
            $condiciones[] = ContextoLaboralSql::procesoId() . ' = ?';
            $params[] = $procesoId;
        }

        $proyecto = $filtros['proyecto'] ?? null;
        if (is_string($proyecto) && $proyecto !== '') {
            $condiciones[] = 'v.proyecto COLLATE utf8mb4_unicode_ci = ?';
            $params[] = $proyecto;
        }

        $cargoId = $filtros['cargo_id_ext'] ?? null;
        if ($cargoId !== null && $cargoId > 0) {
            $condiciones[] = ContextoLaboralSql::cargoId() . ' = ?';
            $params[] = $cargoId;
        }

        $estado = strtolower(trim((string)($filtros['estado_alerta'] ?? 'todas')));
        if ($estado === 'vencidas') {
            $condiciones[] = "v.estado_calculado IN ('VENCIDA', 'PENDIENTE_VENCIDA')";
        } elseif ($estado === 'proximas') {
            $condiciones[] = "v.estado_calculado IN ('PROXIMA_A_VENCER', 'PENDIENTE_PROXIMA_A_VENCER')";
        }

        $tipo = strtoupper(trim((string)($filtros['tipo_alerta'] ?? 'todos')));
        if ($tipo === 'LIMITE_CUMPLIMIENTO' || $tipo === 'VIGENCIA_CUMPLIMIENTO') {
            $condiciones[] = 'v.tipo_alerta COLLATE utf8mb4_unicode_ci = ?';
            $params[] = $tipo;
        }

        $q = trim((string)($filtros['q'] ?? ''));
        if ($q !== '') {
            $like = '%' . $q . '%';
            $condiciones[] = '(per.nombre_completo_nombres_primero LIKE ? OR per.numero_documento LIKE ?)';
            $params[] = $like;
            $params[] = $like;
        }

        $capId = $filtros['capacitacion_id'] ?? null;
        if ($capId !== null && $capId > 0) {
            $condiciones[] = 'v.capacitacion_id = ?';
            $params[] = $capId;
        }

        $desde = $filtros['vencimiento_desde'] ?? null;
        if (is_string($desde) && $desde !== '') {
            $condiciones[] = 'v.fecha_alerta >= ?';
            $params[] = $desde;
        }

        $hasta = $filtros['vencimiento_hasta'] ?? null;
        if (is_string($hasta) && $hasta !== '') {
            $condiciones[] = 'v.fecha_alerta <= ?';
            $params[] = $hasta;
        }

        $where = $condiciones === [] ? '' : ('WHERE ' . implode(' AND ', $condiciones));

        return [$where, $params];
    }

    private function normalizarNombre(string $nombre): string
    {
        $nombre = mb_strtoupper(trim($nombre), 'UTF-8');
        $nombre = strtr($nombre, [
            'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U',
            'Ä' => 'A', 'Ë' => 'E', 'Ï' => 'I', 'Ö' => 'O', 'Ü' => 'U',
            'Ñ' => 'N',
        ]);

        return preg_replace('/\s+/', ' ', $nombre) ?? $nombre;
    }
}
